function normalizeConfiguredBaseUrl(raw?: string): string {
  const trimmed = (raw ?? '').trim().replace(/\/+$/, '');
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return '';
    }
    return parsed.origin + parsed.pathname.replace(/\/+$/, '');
  } catch {
    return '';
  }
}

function readEnvApiBaseUrl(): string | undefined {
  const meta = import.meta as unknown as { env?: { VITE_API_BASE_URL?: string } };
  return meta.env?.VITE_API_BASE_URL;
}

export function resolveApiUrl(
  path: string,
  configuredBaseUrl: string | undefined = readEnvApiBaseUrl()
): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = normalizeConfiguredBaseUrl(configuredBaseUrl);
  return base ? `${base}${normalizedPath}` : normalizedPath;
}

export function resolveWsUrl(
  path: string,
  configuredBaseUrl: string | undefined = readEnvApiBaseUrl(),
  browserLocation?: { protocol: string; host: string }
): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = normalizeConfiguredBaseUrl(configuredBaseUrl);
  if (base) {
    const wsBase = base.replace(/^https:/i, 'wss:').replace(/^http:/i, 'ws:');
    return `${wsBase}${normalizedPath}`;
  }
  const loc =
    browserLocation ??
    (typeof window !== 'undefined' ? window.location : { protocol: 'https:', host: 'localhost:3000' });
  const wsProto = loc.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${wsProto}//${loc.host}${normalizedPath}`;
}

export function apiUrl(path: string): string {
  return resolveApiUrl(path);
}

export function wsUrl(path: string): string {
  return resolveWsUrl(path);
}
