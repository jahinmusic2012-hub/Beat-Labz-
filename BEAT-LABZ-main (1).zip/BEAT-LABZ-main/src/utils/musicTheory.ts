import type { SequencerTrack } from '../types/studio';

export const NOTE_NAMES = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'] as const;
const SHARP_ALIASES: Record<string, string> = {
  Db: 'C#',
  'D#': 'Eb',
  Gb: 'F#',
  'G#': 'Ab',
  'A#': 'Bb',
};

export interface ScaleDefinition {
  id: string;
  name: string;
  intervals: number[];
  description: string;
}

export const SCALES: ScaleDefinition[] = [
  { id: 'major', name: 'Major (Ionian)', intervals: [0, 2, 4, 5, 7, 9, 11], description: 'Bright diatonic scale used across pop, worship, and classical composition.' },
  { id: 'minor', name: 'Natural Minor (Aeolian)', intervals: [0, 2, 3, 5, 7, 8, 10], description: 'Emotive minor scale for moody grooves, ballads, and cinematic pads.' },
  { id: 'dorian', name: 'Dorian Mode', intervals: [0, 2, 3, 5, 7, 9, 10], description: 'Minor scale with a raised 6th — staple of neo-soul, funk, and modern gospel.' },
  { id: 'mixolydian', name: 'Mixolydian Mode', intervals: [0, 2, 4, 5, 7, 9, 10], description: 'Major scale with a flat 7th for anthemic rock and groove riffs.' },
  { id: 'pent_major', name: 'Major Pentatonic', intervals: [0, 2, 4, 7, 9], description: 'Five-note open scale ideal for uplifting melodies and guitar phrasing.' },
  { id: 'pent_minor', name: 'Minor Pentatonic', intervals: [0, 3, 5, 7, 10], description: 'Versatile five-note lead vocabulary for solos, basslines, and R&B hooks.' },
  { id: 'harmonic_minor', name: 'Harmonic Minor', intervals: [0, 2, 3, 5, 7, 8, 11], description: 'Dramatic raised-7th minor tonality for tension and classical cadences.' },
  { id: 'blues', name: 'Blues Scale', intervals: [0, 3, 5, 6, 7, 10], description: 'Minor pentatonic plus the chromatic blue note (b5).' },
];

export interface ChordQuality {
  id: string;
  suffix: string;
  label: string;
  intervals: number[];
}

export const CHORD_QUALITIES: ChordQuality[] = [
  { id: 'maj', suffix: '', label: 'Major Triad', intervals: [0, 4, 7] },
  { id: 'min', suffix: 'm', label: 'Minor Triad', intervals: [0, 3, 7] },
  { id: 'maj7', suffix: 'maj7', label: 'Major 7th', intervals: [0, 4, 7, 11] },
  { id: 'm7', suffix: 'm7', label: 'Minor 7th', intervals: [0, 3, 7, 10] },
  { id: '7', suffix: '7', label: 'Dominant 7th', intervals: [0, 4, 7, 10] },
  { id: 'sus2', suffix: 'sus2', label: 'Suspended 2nd', intervals: [0, 2, 7] },
  { id: 'sus4', suffix: 'sus4', label: 'Suspended 4th', intervals: [0, 5, 7] },
  { id: 'add9', suffix: 'add9', label: 'Add 9', intervals: [0, 4, 7, 14] },
  { id: 'm9', suffix: 'm9', label: 'Minor 9th', intervals: [0, 3, 7, 10, 14] },
  { id: 'dim', suffix: 'dim', label: 'Diminished', intervals: [0, 3, 6] },
];

export function normalizeRootName(root: string): string {
  const clean = root.trim();
  if (SHARP_ALIASES[clean]) return SHARP_ALIASES[clean];
  return clean;
}

export function noteNameToSemitone(root: string): number {
  const normalized = normalizeRootName(root);
  const idx = NOTE_NAMES.indexOf(normalized as (typeof NOTE_NAMES)[number]);
  return idx >= 0 ? idx : 0;
}

export function noteNameToMidi(noteWithOctave: string): number {
  const match = /^([A-G](?:#|b)?)(-?\d+)$/.exec(noteWithOctave.trim());
  if (!match) return 60;
  const [, name, octStr] = match;
  const semi = noteNameToSemitone(name);
  const oct = Number(octStr);
  return (oct + 1) * 12 + semi;
}

export function midiToNoteName(midi: number): string {
  const clamped = Math.max(0, Math.min(127, Math.round(midi)));
  const note = NOTE_NAMES[clamped % 12];
  const octave = Math.floor(clamped / 12) - 1;
  return `${note}${octave}`;
}

export function midiToFreq(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

export function getScaleNotes(root: string, scaleId: string, octave = 4): { names: string[]; midis: number[] } {
  const scale = SCALES.find((s) => s.id === scaleId) ?? SCALES[0];
  const baseMidi = (octave + 1) * 12 + noteNameToSemitone(root);
  const midis = scale.intervals.map((interval) => baseMidi + interval);
  const names = midis.map((m) => NOTE_NAMES[m % 12]);
  return { names, midis };
}

export function getChordNotes(root: string, qualityId: string, octave = 4): { symbol: string; names: string[]; midis: number[] } {
  const quality = CHORD_QUALITIES.find((q) => q.id === qualityId) ?? CHORD_QUALITIES[0];
  const baseMidi = (octave + 1) * 12 + noteNameToSemitone(root);
  const midis = quality.intervals.map((i) => baseMidi + i);
  const names = midis.map((m) => NOTE_NAMES[m % 12]);
  return { symbol: `${normalizeRootName(root)}${quality.suffix}`, names, midis };
}

export function parseChordSymbol(symbol: string, octave = 4): { symbol: string; midis: number[]; names: string[] } {
  const clean = symbol.trim().split('/')[0];
  const match = /^([A-G](?:#|b)?)(.*)$/.exec(clean);
  if (!match) return getChordNotes('C', 'maj', octave);
  const [, root, suffix] = match;
  const quality = CHORD_QUALITIES.find((q) => q.suffix === suffix) ?? CHORD_QUALITIES[0];
  return getChordNotes(root, quality.id, octave);
}

export function transposeChordSymbol(symbol: string, semitones: number): string {
  const parts = symbol.trim().split('/');
  const transposePart = (part: string, isBass: boolean) => {
    const match = /^([A-G](?:#|b)?)(.*)$/.exec(part);
    if (!match) return part;
    const [, root, suffix] = match;
    const semi = (noteNameToSemitone(root) + semitones + 120) % 12;
    return `${NOTE_NAMES[semi]}${isBass ? '' : suffix}`;
  };
  if (parts.length === 2) {
    return `${transposePart(parts[0], false)}/${transposePart(parts[1], true)}`;
  }
  return transposePart(parts[0], false);
}

// Standard Guitar Tuning MIDI: E2(40), A2(45), D3(50), G3(55), B3(59), E4(64)
export const GUITAR_OPEN_MIDI = [40, 45, 50, 55, 59, 64] as const;

export interface GuitarVoicing {
  symbol: string;
  frets: (number | null)[]; // low E to high E; null = muted
  midis: number[];
}

export function getGuitarVoicing(symbol: string): GuitarVoicing {
  const parsed = parseChordSymbol(symbol, 3);
  const chordPitchClasses = new Set(parsed.midis.map((m) => m % 12));
  const rootPc = parsed.midis[0] % 12;

  let foundRoot = false;
  const frets: (number | null)[] = [];
  const midis: number[] = [];

  GUITAR_OPEN_MIDI.forEach((openMidi, strIdx) => {
    // Search frets 0..5 for root first on bass strings, then chord tones
    let chosen: number | null = null;
    if (!foundRoot && strIdx <= 2) {
      for (let f = 0; f <= 5; f++) {
        if ((openMidi + f) % 12 === rootPc) {
          chosen = f;
          foundRoot = true;
          break;
        }
      }
      if (chosen === null) {
        frets.push(null);
        return;
      }
    } else {
      for (let f = 0; f <= 4; f++) {
        if (chordPitchClasses.has((openMidi + f) % 12)) {
          chosen = f;
          break;
        }
      }
    }
    frets.push(chosen);
    if (chosen !== null) {
      midis.push(openMidi + chosen);
    }
  });

  return { symbol: parsed.symbol, frets, midis };
}

function writeVarLen(value: number): number[] {
  let buffer = value & 0x7f;
  const bytes: number[] = [];
  while ((value >>= 7) > 0) {
    buffer <<= 8;
    buffer |= (value & 0x7f) | 0x80;
  }
  while (true) {
    bytes.push(buffer & 0xff);
    if (buffer & 0x80) buffer >>= 8;
    else break;
  }
  return bytes;
}

/**
 * Generates a real Standard MIDI File (.mid, Format 0) from active BEAT LABZ tracks.
 */
export function buildMidiFileBytes(tracks: SequencerTrack[], bpm: number): Uint8Array {
  const ticksPerQuarter = 480;
  const sixteenthTicks = ticksPerQuarter / 4; // 120 ticks
  const microsecondsPerBeat = Math.round(60_000_000 / Math.max(30, Math.min(300, bpm)));

  interface RawMidiEvent {
    tick: number;
    bytes: number[];
  }

  const events: RawMidiEvent[] = [
    // Set Tempo meta event (FF 51 03 tt tt tt)
    {
      tick: 0,
      bytes: [
        0xff,
        0x51,
        0x03,
        (microsecondsPerBeat >> 16) & 0xff,
        (microsecondsPerBeat >> 8) & 0xff,
        microsecondsPerBeat & 0xff,
      ],
    },
  ];

  tracks.forEach((track, trackIdx) => {
    if (track.muted) return;
    const channel = track.kind === 'drums' ? 9 : trackIdx % 9;
    track.steps.forEach((active, stepIdx) => {
      if (!active) return;
      const startTick = stepIdx * sixteenthTicks;
      const endTick = startTick + Math.round(sixteenthTicks * 0.85);
      const note = track.kind === 'drums'
        ? ([36, 38, 42, 46, 39, 45][track.notes[stepIdx] ?? 0] ?? 36)
        : Math.max(24, Math.min(108, track.notes[stepIdx] ?? 60));
      const velocity = Math.max(30, Math.min(127, Math.round(track.volume * 100)));
      events.push({ tick: startTick, bytes: [0x90 | channel, note, velocity] });
      events.push({ tick: endTick, bytes: [0x80 | channel, note, 0] });
    });
  });

  events.sort((a, b) => a.tick - b.tick);

  const trackData: number[] = [];
  let prevTick = 0;
  for (const ev of events) {
    const delta = Math.max(0, ev.tick - prevTick);
    prevTick = ev.tick;
    trackData.push(...writeVarLen(delta), ...ev.bytes);
  }
  // End of Track meta event
  trackData.push(0x00, 0xff, 0x2f, 0x00);

  const header = [
    0x4d, 0x54, 0x68, 0x64, // MThd
    0x00, 0x00, 0x00, 0x06, // header length 6
    0x00, 0x00, // format 0
    0x00, 0x01, // 1 track
    (ticksPerQuarter >> 8) & 0xff,
    ticksPerQuarter & 0xff,
  ];

  const trackLen = trackData.length;
  const trackHeader = [
    0x4d, 0x54, 0x72, 0x6b, // MTrk
    (trackLen >> 24) & 0xff,
    (trackLen >> 16) & 0xff,
    (trackLen >> 8) & 0xff,
    trackLen & 0xff,
  ];

  return new Uint8Array([...header, ...trackHeader, ...trackData]);
}

/**
 * Generates an evenly spaced Euclidean rhythm across `totalSteps` slots.
 */
export function generateEuclideanSteps(pulses: number, totalSteps = 16): boolean[] {
  const clampedSteps = Math.max(1, totalSteps);
  const clampedPulses = Math.max(0, Math.min(clampedSteps, Math.round(pulses)));
  const pattern = new Array<boolean>(clampedSteps).fill(false);
  if (clampedPulses === 0) return pattern;
  let bucket = 0;
  for (let i = 0; i < clampedSteps; i++) {
    bucket += clampedPulses;
    if (bucket >= clampedSteps) {
      bucket -= clampedSteps;
      pattern[i] = true;
    }
  }
  // Rotate so beat 1 starts on a downbeat when pulses > 0
  const firstTrue = pattern.indexOf(true);
  if (firstTrue > 0) {
    return [...pattern.slice(firstTrue), ...pattern.slice(0, firstTrue)];
  }
  return pattern;
}

export function shiftStepArray<T>(arr: T[], delta: number): T[] {
  if (arr.length === 0) return arr;
  const n = arr.length;
  const offset = ((-delta % n) + n) % n;
  return [...arr.slice(offset), ...arr.slice(0, offset)];
}
