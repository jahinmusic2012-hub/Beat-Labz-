import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveApiUrl, resolveWsUrl } from './apiClient.ts';

test('resolveApiUrl preserves same-origin paths when VITE_API_BASE_URL is empty', () => {
  assert.equal(resolveApiUrl('/api/ai/assist', ''), '/api/ai/assist');
  assert.equal(resolveApiUrl('api/shares', undefined), '/api/shares');
});

test('resolveApiUrl targets remote HTTPS backend cleanly for Capacitor APK builds', () => {
  assert.equal(
    resolveApiUrl('/api/audio-objects', 'https://api.beatlabz.example.com/'),
    'https://api.beatlabz.example.com/api/audio-objects'
  );
  // Rejects non-http(s) URL schemes safely
  assert.equal(resolveApiUrl('/api/shares', 'javascript:alert(1)'), '/api/shares');
});

test('resolveWsUrl upgrades http/https API base to ws/wss cleanly', () => {
  assert.equal(
    resolveWsUrl('/ws', 'https://api.beatlabz.example.com/'),
    'wss://api.beatlabz.example.com/ws'
  );
  assert.equal(
    resolveWsUrl('/ws', 'http://192.168.1.25:3000'),
    'ws://192.168.1.25:3000/ws'
  );
  assert.equal(
    resolveWsUrl('/ws', '', { protocol: 'https:', host: 'studio.beatlabz.app' }),
    'wss://studio.beatlabz.app/ws'
  );
});
