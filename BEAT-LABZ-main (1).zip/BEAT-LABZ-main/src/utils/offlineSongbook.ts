import type { StudioProject } from '../types/studio';

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function buildOfflineSongbookHtml(project: StudioProject): string {
  const sectionsHtml = project.chordChart
    .map(
      (section) => `
      <section class="card">
        <div class="section-head">
          <h2>${escapeHtml(section.section)}</h2>
          <span class="meta">${section.bars} bars</span>
        </div>
        <div class="chords">
          ${section.chords.map((ch) => `<span class="chord">${escapeHtml(ch)}</span>`).join('')}
        </div>
        <p class="notes">${escapeHtml(section.lyrics || 'No arrangement notes')}</p>
      </section>`
    )
    .join('\n');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(project.title)} — BEAT LABZ Offline Songbook</title>
  <style>
    body { margin: 0; font-family: system-ui, -apple-system, sans-serif; background: #0A0B0E; color: #F4F4F5; padding: 24px; }
    main { max-width: 820px; margin: 0 auto; }
    header { border-bottom: 1px solid #27272A; padding-bottom: 16px; margin-bottom: 24px; }
    h1 { margin: 0 0 8px 0; font-size: 28px; }
    .meta { color: #A1A1AA; font-size: 13px; }
    .card { background: #12141A; border: 1px solid #27272A; border-radius: 12px; padding: 18px; margin-bottom: 14px; }
    .section-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
    h2 { margin: 0; font-size: 16px; color: #FBBF24; }
    .chords { display: grid; grid-template-columns: repeat(auto-fit, minmax(96px, 1fr)); gap: 10px; margin-bottom: 10px; }
    .chord { background: #191C24; border: 1px solid #3F3F46; border-radius: 8px; padding: 10px; text-align: center; font-weight: 700; font-size: 18px; }
    .notes { margin: 0; color: #D4D4D8; font-size: 14px; line-height: 1.5; }
    footer { margin-top: 24px; color: #71717A; font-size: 12px; }
  </style>
</head>
<body>
  <main>
    <header>
      <h1>${escapeHtml(project.title)}</h1>
      <div class="meta">
        BEAT LABZ Offline Stage Sheet · Key of ${escapeHtml(project.musicalKey)} · ${project.bpm} BPM · ${escapeHtml(project.timeSignature)} · Capo ${project.songbook.capo}
      </div>
    </header>
    ${sectionsHtml}
    <section class="card">
      <h2>Arrangement &amp; Stage Notes</h2>
      <p class="notes">${escapeHtml(project.songbook.notes || 'Ready for live stage performance.')}</p>
    </section>
    <footer>Artist / Collective: ${escapeHtml(project.songbook.artist)} · Exported offline from BEAT LABZ</footer>
  </main>
</body>
</html>`;
}
