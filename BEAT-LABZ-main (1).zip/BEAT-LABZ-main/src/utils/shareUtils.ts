import type { StudioProject } from '../types/studio';

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/?text=${encodeURIComponent(message.trim())}`;
}

export function formatLocationShareMessage(
  coords: { lat: number; lng: number; accuracy?: number },
  label?: string,
  expiresAtIso?: string
): string {
  const cleanLabel = (label ?? 'BEAT LABZ Studio Location').trim();
  const latStr = coords.lat.toFixed(6);
  const lngStr = coords.lng.toFixed(6);
  const mapUrl = `https://maps.google.com/?q=${latStr},${lngStr}`;
  const accPart = typeof coords.accuracy === 'number' ? ` (±${Math.round(coords.accuracy)}m accuracy)` : '';
  const expPart = expiresAtIso ? `\nExpires: ${new Date(expiresAtIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : '';
  return `${cleanLabel}\nCoordinates: ${latStr}, ${lngStr}${accPart}\nMap: ${mapUrl}${expPart}`;
}

export function isLocationShareActive(
  expiresAtMs: number | null,
  stopped: boolean,
  nowMs = Date.now()
): boolean {
  if (stopped || expiresAtMs === null) return false;
  return expiresAtMs > nowMs;
}

export function calculateProjectStorageBytes(project: StudioProject, audioSizeBytes = 0): number {
  const jsonBytes = new TextEncoder().encode(JSON.stringify(project)).length;
  return jsonBytes + Math.max(0, audioSizeBytes);
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
