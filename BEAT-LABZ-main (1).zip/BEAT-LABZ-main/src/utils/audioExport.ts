import { Mp3Encoder } from '@breezystack/lamejs';
import type { MasteringMetrics, MasteringSettings } from '../types/studio';

export function dbToLinear(db: number): number {
  return Math.pow(10, db / 20);
}

export function linearToDb(val: number): number {
  return 20 * Math.log10(Math.max(val, 1e-7));
}

interface BiquadCoeffs {
  b0: number;
  b1: number;
  b2: number;
  a1: number;
  a2: number;
}

function calcLowShelf(freq: number, gainDb: number, sampleRate: number): BiquadCoeffs {
  const A = Math.pow(10, gainDb / 40);
  const w0 = (2 * Math.PI * Math.min(freq, sampleRate * 0.45)) / sampleRate;
  const cosW = Math.cos(w0);
  const sinW = Math.sin(w0);
  const alpha = (sinW / 2) * Math.sqrt((A + 1 / A) * (1 / 0.707 - 1) + 2);
  const twoSqrtAAlpha = 2 * Math.sqrt(A) * alpha;

  const a0 = A + 1 + (A - 1) * cosW + twoSqrtAAlpha;
  return {
    b0: (A * (A + 1 - (A - 1) * cosW + twoSqrtAAlpha)) / a0,
    b1: (2 * A * (A - 1 - (A + 1) * cosW)) / a0,
    b2: (A * (A + 1 - (A - 1) * cosW - twoSqrtAAlpha)) / a0,
    a1: (-2 * (A - 1 + (A + 1) * cosW)) / a0,
    a2: (A + 1 + (A - 1) * cosW - twoSqrtAAlpha) / a0,
  };
}

function calcHighShelf(freq: number, gainDb: number, sampleRate: number): BiquadCoeffs {
  const A = Math.pow(10, gainDb / 40);
  const w0 = (2 * Math.PI * Math.min(freq, sampleRate * 0.45)) / sampleRate;
  const cosW = Math.cos(w0);
  const sinW = Math.sin(w0);
  const alpha = (sinW / 2) * Math.sqrt((A + 1 / A) * (1 / 0.707 - 1) + 2);
  const twoSqrtAAlpha = 2 * Math.sqrt(A) * alpha;

  const a0 = A + 1 - (A - 1) * cosW + twoSqrtAAlpha;
  return {
    b0: (A * (A + 1 + (A - 1) * cosW + twoSqrtAAlpha)) / a0,
    b1: (-2 * A * (A - 1 + (A + 1) * cosW)) / a0,
    b2: (A * (A + 1 + (A - 1) * cosW - twoSqrtAAlpha)) / a0,
    a1: (2 * (A - 1 - (A + 1) * cosW)) / a0,
    a2: (A + 1 - (A - 1) * cosW - twoSqrtAAlpha) / a0,
  };
}

function calcPeakingEQ(freq: number, gainDb: number, q: number, sampleRate: number): BiquadCoeffs {
  const A = Math.pow(10, gainDb / 40);
  const w0 = (2 * Math.PI * Math.min(freq, sampleRate * 0.45)) / sampleRate;
  const cosW = Math.cos(w0);
  const alpha = Math.sin(w0) / (2 * Math.max(0.2, q));

  const a0 = 1 + alpha / A;
  return {
    b0: (1 + alpha * A) / a0,
    b1: (-2 * cosW) / a0,
    b2: (1 - alpha * A) / a0,
    a1: (-2 * cosW) / a0,
    a2: (1 - alpha / A) / a0,
  };
}

function applyBiquad(input: Float32Array, c: BiquadCoeffs): Float32Array {
  const out = new Float32Array(input.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < input.length; i++) {
    const x0 = input[i];
    const y0 = c.b0 * x0 + c.b1 * x1 + c.b2 * x2 - c.a1 * y1 - c.a2 * y2;
    out[i] = y0;
    x2 = x1;
    x1 = x0;
    y2 = y1;
    y1 = y0;
  }
  return out;
}

function compressBand(samples: Float32Array, thresholdDb: number, ratio: number, sampleRate: number): Float32Array {
  const out = new Float32Array(samples.length);
  const attack = Math.exp(-1 / (0.008 * sampleRate));
  const release = Math.exp(-1 / (0.09 * sampleRate));
  const threshLin = dbToLinear(thresholdDb);
  let env = 0;

  for (let i = 0; i < samples.length; i++) {
    const absVal = Math.abs(samples[i]);
    env = absVal > env ? attack * env + (1 - attack) * absVal : release * env + (1 - release) * absVal;
    let gain = 1;
    if (env > threshLin) {
      const overDb = linearToDb(env) - thresholdDb;
      const reducedDb = overDb * (1 - 1 / Math.max(1, ratio));
      gain = dbToLinear(-reducedDb);
    }
    out[i] = samples[i] * gain;
  }
  return out;
}

export function applyMasteringDSP(
  leftIn: Float32Array,
  rightIn: Float32Array,
  sampleRate: number,
  settings: MasteringSettings
): { left: Float32Array; right: Float32Array } {
  const len = Math.min(leftIn.length, rightIn.length);

  const lowC = calcLowShelf(settings.lowFreqHz, settings.lowGainDb, sampleRate);
  const midC = calcPeakingEQ(settings.midFreqHz, settings.midGainDb, settings.midQ, sampleRate);
  const highC = calcHighShelf(settings.highFreqHz, settings.highGainDb, sampleRate);

  const processEQ = (buf: Float32Array) => applyBiquad(applyBiquad(applyBiquad(buf, lowC), midC), highC);
  const eqL = processEQ(leftIn.subarray(0, len));
  const eqR = processEQ(rightIn.subarray(0, len));

  // 3-band crossover via first-order Linkwitz-style splitting for multiband compression
  const alphaLow = Math.exp((-2 * Math.PI * 220) / sampleRate);
  const alphaHigh = Math.exp((-2 * Math.PI * 3200) / sampleRate);

  const splitAndCompress = (buf: Float32Array) => {
    const low = new Float32Array(len);
    const mid = new Float32Array(len);
    const high = new Float32Array(len);
    let lp1 = 0;
    let lp2 = 0;
    for (let i = 0; i < len; i++) {
      lp1 = alphaLow * lp1 + (1 - alphaLow) * buf[i];
      lp2 = alphaHigh * lp2 + (1 - alphaHigh) * buf[i];
      low[i] = lp1;
      mid[i] = lp2 - lp1;
      high[i] = buf[i] - lp2;
    }
    const cLow = compressBand(low, settings.lowBandThresholdDb, settings.compRatio, sampleRate);
    const cMid = compressBand(mid, settings.midBandThresholdDb, settings.compRatio, sampleRate);
    const cHigh = compressBand(high, settings.highBandThresholdDb, settings.compRatio, sampleRate);
    const sum = new Float32Array(len);
    for (let i = 0; i < len; i++) {
      sum[i] = cLow[i] + cMid[i] + cHigh[i];
    }
    return sum;
  };

  const compL = splitAndCompress(eqL);
  const compR = splitAndCompress(eqR);

  // Stereo M/S Width + Makeup Gain + Brickwall Limiter
  const width = settings.stereoWidth;
  const makeup = dbToLinear(settings.makeupGainDb);
  const ceiling = dbToLinear(settings.limiterCeilingDb);
  const limRelease = Math.exp(-1 / (0.05 * sampleRate));
  let limEnv = 1;

  const outL = new Float32Array(len);
  const outR = new Float32Array(len);

  for (let i = 0; i < len; i++) {
    const mid = 0.5 * (compL[i] + compR[i]);
    const side = 0.5 * (compL[i] - compR[i]) * width;
    const rawL = (mid + side) * makeup;
    const rawR = (mid - side) * makeup;

    const peak = Math.max(Math.abs(rawL), Math.abs(rawR));
    const targetGain = peak > ceiling ? ceiling / peak : 1;
    limEnv = targetGain < limEnv ? targetGain : limRelease * limEnv + (1 - limRelease) * targetGain;

    outL[i] = Math.max(-ceiling, Math.min(ceiling, rawL * limEnv));
    outR[i] = Math.max(-ceiling, Math.min(ceiling, rawR * limEnv));
  }

  return { left: outL, right: outR };
}

function biquadMagDb(c: BiquadCoeffs, freqHz: number, sampleRate: number): number {
  const w = (2 * Math.PI * Math.min(freqHz, sampleRate * 0.49)) / sampleRate;
  const cosW = Math.cos(w);
  const sinW = Math.sin(w);
  const cos2W = Math.cos(2 * w);
  const sin2W = Math.sin(2 * w);

  const numRe = c.b0 + c.b1 * cosW + c.b2 * cos2W;
  const numIm = -(c.b1 * sinW + c.b2 * sin2W);
  const denRe = 1 + c.a1 * cosW + c.a2 * cos2W;
  const denIm = -(c.a1 * sinW + c.a2 * sin2W);

  const magSq = (numRe * numRe + numIm * numIm) / Math.max(1e-12, denRe * denRe + denIm * denIm);
  return 10 * Math.log10(Math.max(magSq, 1e-10));
}

export function computeParametricEqResponseDb(
  settings: MasteringSettings,
  sampleRate: number,
  frequencies: number[]
): number[] {
  const lowC = calcLowShelf(settings.lowFreqHz, settings.lowGainDb, sampleRate);
  const midC = calcPeakingEQ(settings.midFreqHz, settings.midGainDb, settings.midQ, sampleRate);
  const highC = calcHighShelf(settings.highFreqHz, settings.highGainDb, sampleRate);

  return frequencies.map(
    (f) => biquadMagDb(lowC, f, sampleRate) + biquadMagDb(midC, f, sampleRate) + biquadMagDb(highC, f, sampleRate)
  );
}

export function analyzeStereoBuffer(
  left: Float32Array,
  right: Float32Array,
  _sampleRate: number
): MasteringMetrics {
  const len = Math.min(left.length, right.length);
  if (len === 0) {
    return {
      lufs: -70,
      rmsDb: -70,
      truePeakDb: -70,
      clippedSamples: 0,
      correlation: 1,
      leftRmsDb: -70,
      rightRmsDb: -70,
    };
  }

  let sumSqL = 0;
  let sumSqR = 0;
  let sumLR = 0;
  let peak = 0;
  let clippedSamples = 0;

  for (let i = 0; i < len; i++) {
    const l = left[i];
    const r = right[i];
    sumSqL += l * l;
    sumSqR += r * r;
    sumLR += l * r;
    const absL = Math.abs(l);
    const absR = Math.abs(r);
    if (absL > peak) peak = absL;
    if (absR > peak) peak = absR;
    if (absL >= 0.999 || absR >= 0.999) clippedSamples++;
  }

  const meanSqL = sumSqL / len;
  const meanSqR = sumSqR / len;
  const meanSqTotal = 0.5 * (meanSqL + meanSqR);
  const rmsDb = 10 * Math.log10(Math.max(meanSqTotal, 1e-10));
  const leftRmsDb = 10 * Math.log10(Math.max(meanSqL, 1e-10));
  const rightRmsDb = 10 * Math.log10(Math.max(meanSqR, 1e-10));
  const lufs = -0.691 + 10 * Math.log10(Math.max(meanSqL + meanSqR, 1e-10));
  const truePeakDb = linearToDb(peak);

  const denom = Math.sqrt(sumSqL * sumSqR);
  const correlation = denom > 1e-12 ? Math.max(-1, Math.min(1, sumLR / denom)) : 1;

  return {
    lufs: Number(lufs.toFixed(1)),
    rmsDb: Number(rmsDb.toFixed(1)),
    truePeakDb: Number(truePeakDb.toFixed(2)),
    clippedSamples,
    correlation: Number(correlation.toFixed(2)),
    leftRmsDb: Number(leftRmsDb.toFixed(1)),
    rightRmsDb: Number(rightRmsDb.toFixed(1)),
  };
}

export function encodeWavBuffer(channels: Float32Array[], sampleRate: number): Uint8Array {
  const numChannels = channels.length;
  const numFrames = channels[0]?.length ?? 0;
  const bytesPerSample = 2;
  const dataSize = numFrames * numChannels * bytesPerSample;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * numChannels * bytesPerSample, true);
  view.setUint16(32, numChannels * bytesPerSample, true);
  view.setUint16(34, 16, true); // bits per sample
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  let offset = 44;
  for (let i = 0; i < numFrames; i++) {
    for (let ch = 0; ch < numChannels; ch++) {
      const sample = Math.max(-1, Math.min(1, channels[ch][i]));
      const int16 = sample < 0 ? Math.round(sample * 0x8000) : Math.round(sample * 0x7fff);
      view.setInt16(offset, int16, true);
      offset += 2;
    }
  }

  return new Uint8Array(buffer);
}

function floatToInt16(input: Float32Array): Int16Array {
  const out = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    out[i] = s < 0 ? Math.round(s * 0x8000) : Math.round(s * 0x7fff);
  }
  return out;
}

export function encodeMp3Buffer(channels: Float32Array[], sampleRate: number, kbps = 192): Uint8Array {
  const numChannels = channels.length >= 2 ? 2 : 1;
  const encoder = new Mp3Encoder(numChannels, sampleRate, kbps);
  const left = floatToInt16(channels[0]);
  const right = numChannels === 2 ? floatToInt16(channels[1]) : undefined;

  const blockSize = 1152;
  const mp3Chunks: Uint8Array[] = [];
  let totalLen = 0;

  for (let i = 0; i < left.length; i += blockSize) {
    const leftChunk = left.subarray(i, i + blockSize);
    const encoded = right
      ? encoder.encodeBuffer(leftChunk, right.subarray(i, i + blockSize))
      : encoder.encodeBuffer(leftChunk);
    if (encoded.length > 0) {
      const copy = new Uint8Array(encoded);
      mp3Chunks.push(copy);
      totalLen += copy.length;
    }
  }

  const flushed = encoder.flush();
  if (flushed.length > 0) {
    const copy = new Uint8Array(flushed);
    mp3Chunks.push(copy);
    totalLen += copy.length;
  }

  const result = new Uint8Array(totalLen);
  let pos = 0;
  for (const chunk of mp3Chunks) {
    result.set(chunk, pos);
    pos += chunk.length;
  }
  return result;
}
