import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';

export interface NativeLifecycleHandlers {
  onBackground?: () => void;
  onResume?: () => void;
  onBackButton?: () => boolean; // return true if handled inside UI
}

export function isNativeApp(): boolean {
  return Capacitor.isNativePlatform();
}

export async function configureNativeStatusBar(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await StatusBar.setOverlaysWebView({ overlay: false });
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#0A0B0E' });
  } catch {
    // StatusBar plugin may not be supported on older Android OEMs; fail gracefully
  }
}

export function registerNativeLifecycle(handlers: NativeLifecycleHandlers): () => void {
  if (!Capacitor.isNativePlatform()) {
    return () => {};
  }

  const cleanupFns: Array<() => void> = [];
  let disposed = false;

  void CapApp.addListener('appStateChange', ({ isActive }) => {
    if (isActive) {
      handlers.onResume?.();
    } else {
      handlers.onBackground?.();
    }
  }).then((handle) => {
    if (disposed) void handle.remove();
    else cleanupFns.push(() => void handle.remove());
  });

  void CapApp.addListener('backButton', ({ canGoBack }) => {
    const handled = handlers.onBackButton?.() ?? false;
    if (handled) return;
    if (canGoBack) {
      window.history.back();
    } else {
      void CapApp.minimizeApp();
    }
  }).then((handle) => {
    if (disposed) void handle.remove();
    else cleanupFns.push(() => void handle.remove());
  });

  return () => {
    disposed = true;
    cleanupFns.forEach((fn) => fn());
  };
}
