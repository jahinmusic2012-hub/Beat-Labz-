import test from 'node:test';
import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import { buildZipBuffer } from './zipBuilder.ts';
import { buildOfflineSongbookHtml } from './offlineSongbook.ts';
import { INITIAL_STUDIO_PROJECT } from '../data/defaultStudio.ts';

test('buildZipBuffer produces valid PKZIP local headers, EOCD, and inflatable entries', () => {
  const sampleText = 'BEAT LABZ studio offline package test payload';
  const zip = buildZipBuffer([
    { name: 'README.txt', data: sampleText },
    { name: 'nested/project.json', data: JSON.stringify({ title: 'Test' }) },
  ]);

  // Local file header signature PK\x03\x04
  assert.equal(zip.readUInt32LE(0), 0x04034b50);
  // EOCD signature PK\x05\x06 at end - 22
  assert.equal(zip.readUInt32LE(zip.length - 22), 0x06054b50);
  assert.equal(zip.readUInt16LE(zip.length - 12), 2); // 2 entries

  // Verify first compressed entry payload inflates back cleanly
  const nameLen = zip.readUInt16LE(26);
  const compSize = zip.readUInt32LE(18);
  const compStart = 30 + nameLen;
  const inflated = zlib.inflateRawSync(zip.subarray(compStart, compStart + compSize)).toString('utf8');
  assert.equal(inflated, sampleText);
});

test('buildOfflineSongbookHtml escapes HTML safely and embeds chords and BPM', () => {
  const html = buildOfflineSongbookHtml({
    ...INITIAL_STUDIO_PROJECT,
    title: 'Grace & <Glory>',
  });

  assert.match(html, /Grace &amp; &lt;Glory&gt;/);
  assert.match(html, /118 BPM/);
  assert.match(html, /Cmaj7|C/);
  assert.match(html, /<!doctype html>/i);
});
