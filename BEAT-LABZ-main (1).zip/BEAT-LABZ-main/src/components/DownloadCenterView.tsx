import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Laptop,
  CheckCircle2,
  Copy,
  Check,
  Share2,
  FileAudio,
  FileCode2,
  FileMusic,
  BookOpen,
  ArrowRight,
  HardDriveDownload,
} from 'lucide-react';
import type { StudioProject } from '../types/studio';
import { usePWAInstall, useOnlineStatus } from '../hooks/usePWAInstall';
import { audioEngine } from '../audio/audioEngine';
import { encodeMp3Buffer, encodeWavBuffer } from '../utils/audioExport';
import { buildMidiFileBytes } from '../utils/musicTheory';
import { buildOfflineSongbookHtml } from '../utils/offlineSongbook';
import { buildWhatsAppUrl } from '../utils/shareUtils';
import { apiUrl } from '../utils/apiClient';
import { isNativeApp } from '../utils/nativeAndroid';

interface DownloadCenterViewProps {
  project: StudioProject;
  isStandaloneDownloadRoute?: boolean;
  onOpenStudio?: () => void;
}

function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const DownloadCenterView: React.FC<DownloadCenterViewProps> = ({
  project,
  isStandaloneDownloadRoute = false,
  onOpenStudio,
}) => {
  const { isInstallable, isInstalled, platform, swReady, install } = usePWAInstall();
  const isOnline = useOnlineStatus();
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [installMessage, setInstallMessage] = useState<string | null>(null);
  const [busyExport, setBusyExport] = useState<'wav' | 'mp3' | null>(null);
  const [exportNote, setExportNote] = useState<string | null>(null);

  const downloadPageUrl =
    typeof window !== 'undefined' ? `${window.location.origin}/download` : '/download';
  const safeBaseName = project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'beat-labz';

  const handleInstallClick = async () => {
    const outcome = await install();
    if (outcome === 'accepted') {
      setInstallMessage('BEAT LABZ installed cleanly onto your device.');
    } else if (outcome === 'dismissed') {
      setInstallMessage('Install prompt dismissed. You can install anytime from your browser menu or here.');
    } else {
      setInstallMessage('Use your browser menu below ("Add to Home Screen" or "Install BEAT LABZ") to save it to your device.');
    }
  };

  const copyDownloadLink = async () => {
    try {
      await navigator.clipboard.writeText(downloadPageUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      setInstallMessage('Copy failed — select and copy the address bar URL directly.');
    }
  };

  const shareDownloadPage = async () => {
    const text = `Download & install BEAT LABZ Music Studio on Android, Desktop, or iPhone: ${downloadPageUrl}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Download BEAT LABZ Studio',
          text: 'Install BEAT LABZ Music Studio or download offline audio packages.',
          url: downloadPageUrl,
        });
        return;
      } catch {
        // Fallback to WhatsApp if user cancelled native share or unavailable
      }
    }
    window.open(buildWhatsAppUrl(text), '_blank', 'noopener,noreferrer');
  };

  const downloadProjectJson = () => {
    const json = JSON.stringify(project, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    triggerBlobDownload(blob, `${safeBaseName}.beatlabz.json`);
    setExportNote(`Downloaded ${safeBaseName}.beatlabz.json`);
  };

  const downloadMidi = () => {
    const bytes = buildMidiFileBytes(project.tracks, project.bpm);
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    triggerBlobDownload(new Blob([copy.buffer], { type: 'audio/midi' }), `${safeBaseName}.mid`);
    setExportNote(`Downloaded ${safeBaseName}.mid`);
  };

  const downloadOfflineHtml = () => {
    const html = buildOfflineSongbookHtml(project);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    triggerBlobDownload(blob, `${safeBaseName}-songbook.html`);
    setExportNote(`Downloaded ${safeBaseName}-songbook.html (opens offline anywhere)`);
  };

  const downloadMasterAudio = async (format: 'wav' | 'mp3') => {
    setBusyExport(format);
    setExportNote(null);
    try {
      const rendered = await audioEngine.renderProjectMixToStereo(
        project.tracks,
        project.bpm,
        2,
        project.mastering,
        project.swing ?? 0
      );
      const bytes =
        format === 'wav'
          ? encodeWavBuffer([rendered.left, rendered.right], rendered.sampleRate)
          : encodeMp3Buffer([rendered.left, rendered.right], rendered.sampleRate, 192);
      const mime = format === 'wav' ? 'audio/wav' : 'audio/mpeg';
      const filename = `${safeBaseName}-master.${format}`;
      triggerBlobDownload(new Blob([new Uint8Array(bytes)], { type: mime }), filename);
      setExportNote(`Rendered & downloaded ${filename} (${(bytes.byteLength / 1024).toFixed(1)} KB)`);
    } catch (err) {
      setExportNote(err instanceof Error ? err.message : 'Audio render failed.');
    } finally {
      setBusyExport(null);
    }
  };

  const platformLabel =
    platform === 'android'
      ? 'Android Device'
      : platform === 'ios'
        ? 'iPhone / iPad (iOS Safari)'
        : 'Desktop Workstation';

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Primary Hero Focal Anchor: Direct App Install & Link Sharing */}
      <section className="studio-rack rounded-2xl p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center gap-3">
            <img
              src="/pwa-192x192.png"
              alt="BEAT LABZ App Icon"
              className="w-14 h-14 rounded-xl border border-zinc-700 shrink-0"
            />
            <div>
              <h1 className="text-2xl lg:text-3xl font-display font-bold text-zinc-100 tracking-tight">
                Download BEAT LABZ
              </h1>
              <p className="text-xs text-zinc-400">
                Detected platform: {platformLabel} · Offline cache: {swReady ? 'Active' : 'Warming up'} · Network: {isOnline ? 'Online' : 'Offline'}
              </p>
            </div>
          </div>

          <p className="text-sm text-zinc-300 leading-relaxed max-w-2xl">
            Install BEAT LABZ directly onto Android, Windows, macOS, Linux, or iOS for standalone full-screen launch and offline studio access, or download the complete source bundle and audio exports below.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            {isNativeApp() || isInstalled ? (
              <div className="px-4 py-2.5 rounded-lg bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-sm font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                {isNativeApp() ? 'Running as Native Android App' : 'Installed as Standalone App'}
              </div>
            ) : isInstallable ? (
              <button
                type="button"
                onClick={handleInstallClick}
                className="px-5 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-4 h-4 shrink-0" />
                Install BEAT LABZ App
              </button>
            ) : (
              <a
                href={apiUrl('/api/download/bundle')}
                download="beat-labz-studio.zip"
                className="px-5 py-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
              >
                <HardDriveDownload className="w-4 h-4 shrink-0" />
                Download Studio Package (.zip)
              </a>
            )}

            {isStandaloneDownloadRoute && onOpenStudio && (
              <button
                type="button"
                onClick={onOpenStudio}
                className="px-4 py-3 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-100 text-sm font-semibold flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                Launch Web Studio <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {installMessage && (
            <p className="text-xs text-amber-300">{installMessage}</p>
          )}
        </div>

        {/* Right Side: Direct Shareable Download URL (clean hairline separation, no nested card) */}
        <div className="lg:col-span-5 lg:border-l lg:border-zinc-800/80 lg:pl-7 space-y-3">
          <div className="text-xs font-semibold text-zinc-300">Share or Open on Mobile</div>
          <div className="bg-[#0B0D12] border border-zinc-800 rounded-lg px-3 py-2 text-xs font-mono text-zinc-300 truncate select-all">
            {downloadPageUrl}
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={copyDownloadLink}
              className="px-3 py-2.5 rounded-lg bg-[#191C24] hover:border-zinc-500 border border-zinc-700 text-xs font-semibold text-zinc-200 flex items-center justify-center gap-1.5 whitespace-nowrap"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedUrl ? 'Copied Link' : 'Copy Link'}
            </button>
            <button
              type="button"
              onClick={shareDownloadPage}
              className="px-3 py-2.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-xs font-semibold text-emerald-300 flex items-center justify-center gap-1.5 whitespace-nowrap"
            >
              <Share2 className="w-3.5 h-3.5" />
              Send to Phone
            </button>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Open this URL on Android Chrome or iOS Safari to install BEAT LABZ straight onto your home screen.
          </p>
        </div>
      </section>

      {/* Platform Installation Instructions */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="studio-rack rounded-xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
            <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Android (Chrome / Edge)</span>
          </div>
          <ol className="text-xs text-zinc-400 space-y-1.5 list-decimal list-inside leading-relaxed">
            <li>Tap <strong>Install BEAT LABZ App</strong> when shown above.</li>
            <li>Or open Chrome menu (<strong>⋮</strong>) and tap <strong>Add to Home screen</strong>.</li>
            <li>Select <strong>Install</strong> to run BEAT LABZ as an Android app.</li>
          </ol>
        </div>

        <div className="studio-rack rounded-xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
            <Laptop className="w-4 h-4 text-sky-400 shrink-0" />
            <span>Desktop (Windows / Mac / Linux)</span>
          </div>
          <ol className="text-xs text-zinc-400 space-y-1.5 list-decimal list-inside leading-relaxed">
            <li>Click the install icon in the right side of the Chrome/Edge address bar.</li>
            <li>Or click <strong>Install BEAT LABZ App</strong> above when ready.</li>
            <li>Launch from Applications, Dock, or Start Menu anytime.</li>
          </ol>
        </div>

        <div className="studio-rack rounded-xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
            <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>iPhone &amp; iPad (Safari)</span>
          </div>
          <ol className="text-xs text-zinc-400 space-y-1.5 list-decimal list-inside leading-relaxed">
            <li>Open this page in <strong>Safari</strong> on iOS or iPadOS.</li>
            <li>Tap the <strong>Share</strong> icon in the toolbar.</li>
            <li>Tap <strong>Add to Home Screen</strong>, then tap <strong>Add</strong>.</li>
          </ol>
        </div>
      </section>

      {/* Direct Offline Files & Active Project Downloads */}
      <section className="studio-rack rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold text-zinc-100">
              Direct File &amp; Offline Studio Downloads
            </h2>
            <p className="text-xs text-zinc-400">
              Active session: {project.title} · {project.musicalKey} · <span className="font-mono tabular-nums">{project.bpm} BPM</span>
            </p>
          </div>
          {exportNote && (
            <div className="text-xs font-medium text-emerald-400">{exportNote}</div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="studio-well rounded-xl p-4 flex flex-col justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
                <FileCode2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Complete App Source (.zip)</span>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Self-hosted BEAT LABZ codebase (<code className="font-mono text-zinc-300">src/</code>, <code className="font-mono text-zinc-300">server.ts</code>, PWA icons) ready to run with <code className="font-mono text-zinc-300">npm install &amp;&amp; npm run dev</code>.
              </p>
            </div>
            <a
              href={apiUrl('/api/download/bundle')}
              download="beat-labz-studio.zip"
              className="w-full py-2.5 px-4 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-100 text-xs font-semibold flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Download ZIP Bundle
            </a>
          </div>

          <div className="studio-well rounded-xl p-4 flex flex-col justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
                <FileAudio className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Mastered Mix (WAV / MP3)</span>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Renders your active tracks through the Mastering EQ, 3-band compressor, stereo matrix, and true-peak limiter.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={busyExport !== null}
                onClick={() => downloadMasterAudio('wav')}
                className="py-2.5 px-3 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-100 text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5" />
                {busyExport === 'wav' ? 'Rendering...' : 'WAV'}
              </button>
              <button
                type="button"
                disabled={busyExport !== null}
                onClick={() => downloadMasterAudio('mp3')}
                className="py-2.5 px-3 rounded-lg bg-[#191C24] hover:border-emerald-500 border border-zinc-700 text-zinc-100 text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5" />
                {busyExport === 'mp3' ? 'Encoding...' : 'MP3'}
              </button>
            </div>
          </div>

          <div className="studio-well rounded-xl p-4 flex flex-col justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
                <FileMusic className="w-4 h-4 text-sky-400 shrink-0" />
                <span>MIDI &amp; Project Backup</span>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Export Standard MIDI (<code className="font-mono text-zinc-300">.mid</code>) for hardware synths or DAWs, or save the full <code className="font-mono text-zinc-300">.beatlabz.json</code> project file.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={downloadMidi}
                className="py-2.5 px-3 rounded-lg bg-[#191C24] hover:border-sky-500 border border-zinc-700 text-zinc-100 text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                MIDI
              </button>
              <button
                type="button"
                onClick={downloadProjectJson}
                className="py-2.5 px-3 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-100 text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                JSON
              </button>
            </div>
          </div>

          <div className="studio-well rounded-xl p-4 flex flex-col justify-between gap-4 md:col-span-2 lg:col-span-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm font-semibold text-zinc-100">
                  <BookOpen className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Offline Stage Songbook (.html)</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Generates a clean, self-contained HTML chord chart &amp; stage cue file you can open directly in any mobile or tablet browser without internet.
                </p>
              </div>
              <button
                type="button"
                onClick={downloadOfflineHtml}
                className="px-4 py-2.5 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-100 text-xs font-semibold flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                Download Offline Songbook
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
