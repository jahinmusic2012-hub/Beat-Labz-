import React, { useState } from 'react';
import { Download, CheckCircle2, Smartphone, X } from 'lucide-react';
import { usePWAInstall, useOnlineStatus } from '../hooks/usePWAInstall';
import { isNativeApp } from '../utils/nativeAndroid';

interface PWAInstallButtonProps {
  onOpenDownloadPage?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onOpenDownloadPage }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isNativeApp() || isInstalled) {
    return (
      <div className="px-3 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-300 flex items-center gap-2">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        <span>{isNativeApp() ? 'Android App Active' : 'App Installed'}</span>
      </div>
    );
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => {
          void install();
        }}
        className="w-full px-3 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
      >
        <Download className="w-3.5 h-3.5 shrink-0" />
        Install App
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="w-full px-3 py-2.5 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
        >
          <Smartphone className="w-3.5 h-3.5 shrink-0" />
          Install on iOS
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
            <div className="w-full max-w-sm rounded-xl bg-[#12141A] border border-zinc-800 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-zinc-100">Install on iPhone or iPad</h3>
                <button
                  type="button"
                  aria-label="Close iOS install instructions"
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <ol className="text-sm text-zinc-300 space-y-2 list-decimal list-inside">
                <li>Tap the <strong>Share</strong> button in Safari.</li>
                <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
                <li>Tap <strong>Add</strong> to launch BEAT LABZ full-screen offline.</li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2 rounded-lg bg-amber-500 text-zinc-950 text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  if (!onOpenDownloadPage) return null;

  return (
    <button
      type="button"
      onClick={onOpenDownloadPage}
      className="w-full px-3 py-2.5 rounded-lg bg-[#191C24] hover:border-amber-500 border border-zinc-700 text-zinc-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
    >
      <Download className="w-3.5 h-3.5 shrink-0" />
      Get App & Downloads
    </button>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-16 lg:bottom-4 left-4 z-50 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-semibold text-zinc-950 shadow-lg">
      Offline Mode · Using cached studio assets
    </div>
  );
};
