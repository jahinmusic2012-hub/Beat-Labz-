import React, { useState, useCallback } from 'react';
import {
  APIProvider,
  Map as GoogleMap,
  AdvancedMarker,
  Pin,
  InfoWindow,
  useAdvancedMarkerRef,
} from '@vis.gl/react-google-maps';
import { MapPin, ShieldCheck, ShieldAlert, MessageCircle, StopCircle, Navigation } from 'lucide-react';
import { buildWhatsAppUrl, formatLocationShareMessage, isLocationShareActive } from '../utils/shareUtils';
import { apiUrl } from '../utils/apiClient';

interface LocationShareViewProps {
  mapsApiKey: string;
}

export const LocationShareView: React.FC<LocationShareViewProps> = ({ mapsApiKey }) => {
  const [coords, setCoords] = useState<{ lat: number; lng: number; accuracy: number } | null>(null);
  const [geoStatus, setGeoStatus] = useState<'idle' | 'requesting' | 'granted' | 'denied'>('idle');
  const [geoError, setGeoError] = useState<string | null>(null);
  const [sessionLabel, setSessionLabel] = useState('BEAT LABZ Rehearsal / Session');
  const [collaboratorName, setCollaboratorName] = useState('Bandmate');
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [explicitConsent, setExplicitConsent] = useState(false);

  const [shareToken, setShareToken] = useState<string | null>(null);
  const [expiresAtMs, setExpiresAtMs] = useState<number | null>(null);
  const [stopped, setStopped] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [infoOpen, setInfoOpen] = useState(false);

  const [markerRef, markerInstance] = useAdvancedMarkerRef();

  const shareIsLive = isLocationShareActive(expiresAtMs, stopped);

  const requestCurrentLocation = useCallback(() => {
    setGeoError(null);
    if (!navigator.geolocation) {
      setGeoStatus('denied');
      setGeoError('Browser geolocation is not supported on this device.');
      return;
    }
    setGeoStatus('requesting');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        });
        setGeoStatus('granted');
        setInfoOpen(true);
      },
      (err) => {
        setGeoStatus('denied');
        setGeoError(err.message || 'Location permission was denied or unavailable.');
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  }, []);

  const startTemporaryShare = async () => {
    if (!coords || !explicitConsent) return;
    setGeoError(null);
    try {
      const res = await fetch(apiUrl('/api/location-shares'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lat: coords.lat,
          lng: coords.lng,
          accuracy: coords.accuracy,
          label: sessionLabel,
          collaboratorName,
          durationMinutes,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create temporary location share.');
      setShareToken(data.token);
      setExpiresAtMs(new Date(data.expiresAt).getTime());
      setStopped(false);
      setShareUrl(`${window.location.origin}${data.shareUrlPath}`);
    } catch (err) {
      setGeoError(err instanceof Error ? err.message : 'Unable to start temporary share.');
    }
  };

  const stopSharingImmediately = async () => {
    if (shareToken) {
      try {
        await fetch(apiUrl(`/api/location-shares/${shareToken}`), { method: 'DELETE' });
      } catch {
        // Best-effort server revoke
      }
    }
    setStopped(true);
    setShareToken(null);
    setExpiresAtMs(null);
    setShareUrl(null);
    setExplicitConsent(false);
  };

  const generatedMessage = coords
    ? formatLocationShareMessage(
        coords,
        sessionLabel,
        expiresAtMs ? new Date(expiresAtMs).toISOString() : undefined
      ) + (shareUrl ? `\nTemporary Collaborator Link: ${shareUrl}` : '')
    : '';

  return (
    <div className="space-y-6">
      {/* Header & Explicit Privacy Status Indicator */}
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Location Sharing</h1>
          <p className="text-sm text-zinc-400">
            Opt-in studio meetup coordinates with explicit browser permission, Google Maps view, and instant Stop Sharing control
          </p>
        </div>

        <div
          data-testid="location-privacy-status"
          className={`px-4 py-2.5 rounded-lg border flex items-center gap-2 text-xs font-semibold ${
            shareIsLive
              ? 'bg-amber-500/15 border-amber-500/50 text-amber-300'
              : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
          }`}
        >
          {shareIsLive ? <ShieldAlert className="w-4 h-4 shrink-0" /> : <ShieldCheck className="w-4 h-4 shrink-0" />}
          <span>
            {shareIsLive
              ? `Temporary Collaborator Share Active (until ${new Date(expiresAtMs!).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`
              : 'Private: Location Not Shared'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls & Consent Panel */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">1. Explicit Permission & Controls</h2>
          <p className="text-xs text-zinc-400 leading-relaxed">
            BEAT LABZ never reads or shares your location automatically. Click below to request your browser&apos;s current GPS coordinates.
          </p>

          <button
            type="button"
            onClick={requestCurrentLocation}
            disabled={geoStatus === 'requesting'}
            className="w-full py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-semibold flex items-center justify-center gap-2"
          >
            <Navigation className="w-4 h-4" />
            {geoStatus === 'requesting' ? 'Requesting Permission...' : 'Detect My Current Location'}
          </button>

          {geoError && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {geoError}
            </div>
          )}

          {coords && (
            <div className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 text-xs font-mono text-zinc-200 space-y-1 tabular-nums">
              <div>Latitude: {coords.lat.toFixed(6)}</div>
              <div>Longitude: {coords.lng.toFixed(6)}</div>
              <div className="text-zinc-400">Accuracy: ±{Math.round(coords.accuracy)} m</div>
            </div>
          )}

          <div className="space-y-3 pt-2 border-t border-zinc-800">
            <label className="block space-y-1">
              <span className="text-xs text-zinc-400">Session / Meetup Label</span>
              <input
                type="text"
                value={sessionLabel}
                onChange={(e) => setSessionLabel(e.target.value)}
                className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              />
            </label>

            <div className="grid grid-cols-2 gap-2">
              <label className="block space-y-1">
                <span className="text-xs text-zinc-400">Collaborator</span>
                <input
                  type="text"
                  value={collaboratorName}
                  onChange={(e) => setCollaboratorName(e.target.value)}
                  className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
                />
              </label>
              <label className="block space-y-1">
                <span className="text-xs text-zinc-400">Expiry</span>
                <select
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(Number(e.target.value))}
                  className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
                >
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={60}>1 hour</option>
                  <option value={120}>2 hours</option>
                </select>
              </label>
            </div>

            <label className="flex items-start gap-2 text-xs text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={explicitConsent}
                onChange={(e) => setExplicitConsent(e.target.checked)}
                className="mt-0.5 accent-amber-500"
              />
              <span>I explicitly confirm sharing my coordinates privately with {collaboratorName || 'my collaborator'} only.</span>
            </label>

            <div className="space-y-2">
              <button
                type="button"
                disabled={!coords || !explicitConsent}
                onClick={startTemporaryShare}
                className="w-full py-2.5 px-4 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-xs font-semibold text-zinc-100"
              >
                Create Temporary Collaborator Share
              </button>

              {shareIsLive && (
                <button
                  type="button"
                  onClick={stopSharingImmediately}
                  className="w-full py-2.5 px-4 rounded-lg bg-red-600 hover:bg-red-500 text-xs font-bold text-white flex items-center justify-center gap-2"
                >
                  <StopCircle className="w-4 h-4" /> Stop Sharing Immediately
                </button>
              )}
            </div>
          </div>

          {coords && explicitConsent && (
            <div className="pt-2 border-t border-zinc-800 space-y-2">
              <div className="text-xs text-zinc-400">Location Share Message</div>
              <pre className="p-2.5 rounded-lg bg-[#0D0F14] border border-zinc-800 text-[11px] font-mono text-zinc-300 whitespace-pre-wrap">
                {generatedMessage}
              </pre>
              <a
                href={buildWhatsAppUrl(generatedMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" /> Share Location via WhatsApp
              </a>
            </div>
          )}
        </div>

        {/* Interactive Google Map Canvas */}
        <div className="lg:col-span-2 bg-[#12141A] border border-zinc-800 rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-400" /> Interactive Studio Map
            </span>
            <span className="text-xs text-zinc-400">
              {coords ? 'Showing verified device coordinates' : 'Awaiting your permission to display your pin'}
            </span>
          </div>

          <div className="w-full h-[460px] rounded-xl overflow-hidden border border-zinc-800 bg-[#0D0F14]">
            {mapsApiKey ? (
              <APIProvider apiKey={mapsApiKey}>
                <GoogleMap
                  mapId="DEMO_MAP_ID"
                  center={coords ? { lat: coords.lat, lng: coords.lng } : { lat: 37.7749, lng: -122.4194 }}
                  zoom={coords ? 15 : 4}
                  gestureHandling="greedy"
                  internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                  style={{ width: '100%', height: '100%' }}
                >
                  {coords && (
                    <>
                      <AdvancedMarker
                        ref={markerRef}
                        position={{ lat: coords.lat, lng: coords.lng }}
                        title={sessionLabel}
                        onClick={() => setInfoOpen(true)}
                      >
                        <Pin background="#F59E0B" borderColor="#78350F" glyphColor="#0A0B0E" />
                      </AdvancedMarker>
                      {infoOpen && markerInstance && (
                        <InfoWindow anchor={markerInstance} onCloseClick={() => setInfoOpen(false)}>
                          <div className="text-zinc-900 p-1 space-y-1">
                            <div className="font-bold text-xs">{sessionLabel}</div>
                            <div className="text-[11px] font-mono">
                              {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
                            </div>
                          </div>
                        </InfoWindow>
                      )}
                    </>
                  )}
                </GoogleMap>
              </APIProvider>
            ) : (
              <div className="h-full flex items-center justify-center p-6 text-center text-sm text-zinc-400">
                Google Maps API key is not present in runtime configuration. Enable Google Maps in Settings to render the interactive map.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
