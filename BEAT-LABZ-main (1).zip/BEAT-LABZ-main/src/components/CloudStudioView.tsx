import React, { useEffect, useState } from 'react';
import {
  getRedirectResult,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
  getDocs,
  deleteDoc,
} from 'firebase/firestore';
import {
  Cloud,
  LogIn,
  LogOut,
  History,
  RotateCcw,
  Upload,
  Lock,
  Globe,
  UserPlus,
  Trash2,
} from 'lucide-react';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';
import type { RecordedTake, StudioProject } from '../types/studio';
import { calculateProjectStorageBytes, formatBytes } from '../utils/shareUtils';
import { apiUrl } from '../utils/apiClient';

interface CloudStudioViewProps {
  user: User | null;
  authReady: boolean;
  project: StudioProject;
  onRestoreProject: (restored: StudioProject) => void;
  recordings: RecordedTake[];
}

interface CloudProjectDoc {
  id: string;
  ownerId: string;
  title: string;
  bpm: number;
  timeSignature: string;
  musicalKey: string;
  isPrivate: boolean;
  shareToken?: string;
  storageBytes: number;
  tracks: StudioProject['tracks'];
  chordChart: StudioProject['chordChart'];
  songbook: StudioProject['songbook'];
  mastering: StudioProject['mastering'];
  collaboratorEmails?: string[];
}

interface CloudVersionDoc {
  id: string;
  projectId: string;
  ownerId: string;
  label: string;
  bpm: number;
  musicalKey: string;
  tracks?: StudioProject['tracks'];
  chordChart?: StudioProject['chordChart'];
  mastering?: StudioProject['mastering'];
}

interface ObjectStorageItem {
  id: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  projectId: string;
  createdAt: string;
}

export const CloudStudioView: React.FC<CloudStudioViewProps> = ({
  user,
  authReady,
  project,
  onRestoreProject,
  recordings,
}) => {
  const [cloudProjects, setCloudProjects] = useState<CloudProjectDoc[]>([]);
  const [versions, setVersions] = useState<CloudVersionDoc[]>([]);
  const [audioObjects, setAudioObjects] = useState<ObjectStorageItem[]>([]);
  const [audioTotalBytes, setAudioTotalBytes] = useState(0);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);
  const [cloudError, setCloudError] = useState<string | null>(null);
  const [versionLabel, setVersionLabel] = useState('Pre-Mix Checkpoint');
  const [collabEmail, setCollabEmail] = useState('');
  const [collabName, setCollabName] = useState('');
  const [collabRole, setCollabRole] = useState<'editor' | 'commenter' | 'viewer'>('editor');

  const loadAudioObjects = async () => {
    try {
      const res = await fetch(apiUrl('/api/audio-objects'));
      if (res.ok) {
        const data = await res.json();
        setAudioObjects(data.items ?? []);
        setAudioTotalBytes(data.totalBytes ?? 0);
      }
    } catch {
      // Ignore offline fetch failure
    }
  };

  useEffect(() => {
    void loadAudioObjects();
    void getRedirectResult(auth).catch((err) => {
      if (err instanceof Error) setCloudError(err.message);
    });
  }, [recordings.length]);

  useEffect(() => {
    if (!authReady || !user) {
      setCloudProjects([]);
      setVersions([]);
      return;
    }

    const q = query(collection(db, 'projects'), where('ownerId', '==', user.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const docs = snap.docs.map((d) => d.data() as CloudProjectDoc);
        setCloudProjects(docs);
      },
      (err) => {
        setCloudError(err.message);
        handleFirestoreError(err, OperationType.LIST, 'projects');
      }
    );
    return () => unsub();
  }, [authReady, user]);

  useEffect(() => {
    if (!authReady || !user || !project.id) {
      setVersions([]);
      return;
    }
    const q = query(
      collection(db, 'projects', project.id, 'versions'),
      where('ownerId', '==', user.uid)
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        setVersions(snap.docs.map((d) => d.data() as CloudVersionDoc));
      },
      () => {
        // Project might not yet be synced to Firestore
        setVersions([]);
      }
    );
    return () => unsub();
  }, [authReady, user, project.id]);

  const handleGoogleSignIn = async () => {
    setCloudError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const code = (err as { code?: string })?.code ?? '';
      if (code === 'auth/popup-blocked' || code === 'auth/operation-not-supported-in-this-environment') {
        try {
          await signInWithRedirect(auth, googleProvider);
          return;
        } catch (redirectErr) {
          setCloudError(redirectErr instanceof Error ? redirectErr.message : 'Google sign-in redirect failed.');
          return;
        }
      }
      setCloudError(err instanceof Error ? err.message : 'Google sign-in failed.');
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setSyncStatus('Signed out from Cloud Studio.');
  };

  const sanitizeProjectId = (raw: string) => raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120) || 'proj_default';

  const syncProjectToCloud = async () => {
    if (!user) return;
    setCloudError(null);
    setSyncStatus('Synchronizing project to Firestore...');
    const pid = sanitizeProjectId(project.id);
    const projPath = `projects/${pid}`;
    try {
      // Ensure user public & private profile docs exist cleanly (PII isolated)
      await setDoc(
        doc(db, 'users', user.uid),
        {
          uid: user.uid,
          displayName: (user.displayName || 'BEAT LABZ Producer').slice(0, 80),
          photoURL: (user.photoURL || '').slice(0, 500),
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      if (user.email) {
        await setDoc(
          doc(db, 'users', user.uid, 'private', 'info'),
          {
            uid: user.uid,
            email: user.email,
            updatedAt: serverTimestamp(),
          },
          { merge: true }
        );
      }

      const existing = cloudProjects.find((p) => p.id === pid);
      const storageBytes = calculateProjectStorageBytes(project, audioTotalBytes);

      const payload: Record<string, unknown> = {
        id: pid,
        ownerId: user.uid,
        title: project.title.slice(0, 120) || 'Untitled Project',
        bpm: Math.max(30, Math.min(300, project.bpm)),
        timeSignature: project.timeSignature.slice(0, 12),
        musicalKey: project.musicalKey.slice(0, 24),
        isPrivate: project.isPrivate,
        storageBytes,
        tracks: project.tracks.slice(0, 16),
        chordChart: project.chordChart.slice(0, 64),
        songbook: project.songbook,
        mastering: project.mastering,
        collaboratorEmails: existing?.collaboratorEmails ?? [],
        createdAt: existing ? undefined : serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      if (existing) delete payload.createdAt;
      if (project.shareToken) payload.shareToken = project.shareToken;

      await setDoc(doc(db, 'projects', pid), payload, { merge: true });
      setSyncStatus(`Synced "${project.title}" to Cloud Studio.`);
    } catch (err) {
      setCloudError(err instanceof Error ? err.message : 'Cloud sync failed.');
      setSyncStatus(null);
      handleFirestoreError(err, OperationType.WRITE, projPath);
    }
  };

  const saveVersionSnapshot = async () => {
    if (!user) return;
    const pid = sanitizeProjectId(project.id);
    const vid = `ver_${Date.now()}`;
    try {
      const parentSnap = await getDocs(query(collection(db, 'projects'), where('ownerId', '==', user.uid)));
      if (!parentSnap.docs.some((d) => d.id === pid)) {
        await syncProjectToCloud();
      }
      await setDoc(doc(db, 'projects', pid, 'versions', vid), {
        id: vid,
        projectId: pid,
        ownerId: user.uid,
        label: versionLabel.trim().slice(0, 120) || 'Version Snapshot',
        bpm: project.bpm,
        musicalKey: project.musicalKey,
        tracks: project.tracks.slice(0, 16),
        chordChart: project.chordChart.slice(0, 64),
        mastering: project.mastering,
        createdAt: serverTimestamp(),
      });
      setSyncStatus(`Saved version snapshot "${versionLabel}".`);
    } catch (err) {
      setCloudError(err instanceof Error ? err.message : 'Failed to save version.');
      handleFirestoreError(err, OperationType.CREATE, `projects/${pid}/versions/${vid}`);
    }
  };

  const addCloudCollaborator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !collabEmail.trim()) return;
    const pid = sanitizeProjectId(project.id);
    const cid = `col_${Date.now()}`;
    try {
      const existing = cloudProjects.find((p) => p.id === pid);
      if (!existing) await syncProjectToCloud();
      const nextEmails = Array.from(new Set([...(existing?.collaboratorEmails ?? []), collabEmail.trim().toLowerCase()])).slice(0, 20);
      await setDoc(
        doc(db, 'projects', pid),
        {
          collaboratorEmails: nextEmails,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      await setDoc(doc(db, 'projects', pid, 'collaborators', cid), {
        id: cid,
        projectId: pid,
        email: collabEmail.trim().toLowerCase(),
        displayName: (collabName.trim() || collabEmail.split('@')[0]).slice(0, 80),
        role: collabRole,
        addedBy: user.uid,
        createdAt: serverTimestamp(),
      });
      setCollabEmail('');
      setCollabName('');
      setSyncStatus(`Granted ${collabRole} access to ${collabEmail.trim()}.`);
    } catch (err) {
      setCloudError(err instanceof Error ? err.message : 'Failed to grant collaborator permission.');
    }
  };

  const deleteAudioObject = async (id: string) => {
    try {
      const res = await fetch(apiUrl(`/api/audio-objects/${id}`), { method: 'DELETE' });
      if (res.ok) await loadAudioObjects();
    } catch {
      // ignore
    }
  };

  const projectPayloadBytes = calculateProjectStorageBytes(project, 0);
  const totalUsedBytes = projectPayloadBytes + audioTotalBytes;
  const quotaBytes = 500 * 1024 * 1024; // 500 MB Studio Storage Tier
  const usagePct = Math.min(100, (totalUsedBytes / quotaBytes) * 100);

  return (
    <div className="space-y-6">
      {/* Header & Auth */}
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Cloud Studio</h1>
          <p className="text-sm text-zinc-400">
            Firebase Authentication, Firestore project sync, version history, collaborator permissions, and object-storage audio backup
          </p>
        </div>

        <div className="flex items-center gap-3">
          {user ? (
            <>
              <div className="text-right">
                <div className="text-xs font-semibold text-zinc-100">{user.displayName || 'Producer'}</div>
                <div className="text-[11px] text-zinc-400">{user.email}</div>
              </div>
              <button
                type="button"
                onClick={handleSignOut}
                className="px-3.5 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" /> Sign Out
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-semibold flex items-center gap-2"
            >
              <LogIn className="w-4 h-4" /> Sign In with Google
            </button>
          )}
        </div>
      </div>

      {/* Real Storage Usage Display */}
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-sm font-semibold text-zinc-100">Studio Storage & Audio Object Backup</span>
          <span className="text-xs font-mono text-zinc-300 tabular-nums">
            {formatBytes(totalUsedBytes)} / {formatBytes(quotaBytes)} ({usagePct.toFixed(2)}%)
          </span>
        </div>
        <div className="h-2.5 w-full rounded-full bg-zinc-900 overflow-hidden border border-zinc-800">
          <div className="h-full bg-amber-500 transition-all" style={{ width: `${Math.max(1, usagePct)}%` }} />
        </div>
        <div className="flex flex-wrap gap-4 text-xs text-zinc-400">
          <span>Project Metadata & MIDI/Patterns: {formatBytes(projectPayloadBytes)}</span>
          <span>Audio Object Storage ({audioObjects.length} files): {formatBytes(audioTotalBytes)}</span>
        </div>
      </div>

      {syncStatus && <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300">{syncStatus}</div>}
      {cloudError && <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">{cloudError}</div>}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sync & Cloud Projects */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-zinc-100">Project Sync</h2>
            <span className="text-xs text-zinc-400 flex items-center gap-1">
              {project.isPrivate ? <Lock className="w-3.5 h-3.5 text-amber-400" /> : <Globe className="w-3.5 h-3.5 text-emerald-400" />}
              {project.isPrivate ? 'Private' : 'Shared'}
            </span>
          </div>

          <button
            type="button"
            disabled={!user}
            onClick={syncProjectToCloud}
            className="w-full py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-zinc-950 text-sm font-semibold flex items-center justify-center gap-2"
          >
            <Cloud className="w-4 h-4" />
            {user ? 'Sync Active Project Now' : 'Sign In to Sync to Firestore'}
          </button>

          <div className="space-y-2 pt-2 border-t border-zinc-800">
            <div className="text-xs font-medium text-zinc-400">Cloud Projects ({cloudProjects.length})</div>
            {!user ? (
              <p className="text-xs text-zinc-500">Sign in with Google to browse and restore your Firestore cloud projects.</p>
            ) : cloudProjects.length === 0 ? (
              <p className="text-xs text-zinc-500">No projects synced yet. Click &quot;Sync Active Project Now&quot; above.</p>
            ) : (
              cloudProjects.map((cp) => (
                <div key={cp.id} className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-zinc-100 truncate">{cp.title}</div>
                    <div className="text-[11px] font-mono text-zinc-400">{cp.bpm} BPM · {cp.musicalKey}</div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        onRestoreProject({
                          id: cp.id,
                          title: cp.title,
                          bpm: cp.bpm,
                          timeSignature: cp.timeSignature,
                          musicalKey: cp.musicalKey,
                          isPrivate: cp.isPrivate,
                          shareToken: cp.shareToken,
                          tracks: cp.tracks,
                          chordChart: cp.chordChart,
                          songbook: cp.songbook,
                          mastering: cp.mastering,
                          updatedAt: new Date().toISOString(),
                        });
                        setSyncStatus(`Restored "${cp.title}" from Cloud Studio.`);
                      }}
                      className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs text-amber-400 flex items-center gap-1"
                    >
                      <RotateCcw className="w-3 h-3" /> Restore
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete cloud project ${cp.title}`}
                      onClick={() => void deleteDoc(doc(db, 'projects', cp.id))}
                      className="p-1 text-zinc-500 hover:text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Version History & Collaborator Permissions */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-5">
          <div className="space-y-3">
            <h2 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
              <History className="w-4 h-4 text-amber-400" /> Version History
            </h2>
            <div className="flex gap-2">
              <input
                type="text"
                aria-label="Version label"
                value={versionLabel}
                onChange={(e) => setVersionLabel(e.target.value)}
                className="flex-1 bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              />
              <button
                type="button"
                disabled={!user}
                onClick={saveVersionSnapshot}
                className="px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-xs font-semibold text-zinc-100 whitespace-nowrap"
              >
                Save Snapshot
              </button>
            </div>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {versions.length === 0 ? (
                <p className="text-xs text-zinc-500">No snapshots saved for this project yet.</p>
              ) : (
                versions.map((v) => (
                  <div key={v.id} className="p-2.5 rounded-lg bg-[#191C24] border border-zinc-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-medium text-zinc-100">{v.label}</div>
                      <div className="text-[11px] font-mono text-zinc-400">{v.bpm} BPM · {v.musicalKey}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onRestoreProject({
                          ...project,
                          bpm: v.bpm,
                          musicalKey: v.musicalKey,
                          tracks: v.tracks ?? project.tracks,
                          chordChart: v.chordChart ?? project.chordChart,
                          mastering: v.mastering ?? project.mastering,
                          updatedAt: new Date().toISOString(),
                        });
                        setSyncStatus(`Restored snapshot "${v.label}".`);
                      }}
                      className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs text-amber-400"
                    >
                      Restore
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          <form onSubmit={addCloudCollaborator} className="space-y-2.5 pt-3 border-t border-zinc-800">
            <div className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <UserPlus className="w-3.5 h-3.5 text-emerald-400" /> Cloud Collaborator Permissions
            </div>
            <input
              type="email"
              placeholder="collaborator@gmail.com"
              value={collabEmail}
              onChange={(e) => setCollabEmail(e.target.value)}
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Display Name"
                value={collabName}
                onChange={(e) => setCollabName(e.target.value)}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              />
              <select
                aria-label="Permission role"
                value={collabRole}
                onChange={(e) => setCollabRole(e.target.value as typeof collabRole)}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              >
                <option value="editor">Editor</option>
                <option value="commenter">Commenter</option>
                <option value="viewer">Viewer</option>
              </select>
            </div>
            <button
              type="submit"
              disabled={!user}
              className="w-full py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-xs font-semibold text-zinc-100"
            >
              Grant Firestore Access
            </button>
          </form>
        </div>

        {/* Audio Object Storage Backup List */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-zinc-100">Audio Object Backups</h2>
            <Upload className="w-4 h-4 text-zinc-400" />
          </div>
          <p className="text-xs text-zinc-400">
            Large WAV, MP3, and WebM stems are stored in dedicated binary object storage rather than inside 1 MB Firestore documents.
          </p>
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {audioObjects.length === 0 ? (
              <div className="p-4 text-center border border-dashed border-zinc-800 rounded-lg text-xs text-zinc-500">
                No audio objects backed up yet. Export a mix in Mastering Lab or upload an audio file in Collaboration Studio.
              </div>
            ) : (
              audioObjects.map((item) => (
                <div key={item.id} className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-zinc-100 truncate">{item.fileName}</div>
                    <div className="text-[11px] font-mono text-zinc-400 tabular-nums">
                      {item.mimeType} · {formatBytes(item.sizeBytes)}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <a
                      href={apiUrl(`/api/audio-objects/${item.id}`)}
                      download={item.fileName}
                      className="text-xs text-amber-400 hover:underline"
                    >
                      Download
                    </a>
                    <button
                      type="button"
                      aria-label={`Delete backup ${item.fileName}`}
                      onClick={() => deleteAudioObject(item.id)}
                      className="p-1 text-zinc-500 hover:text-red-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
