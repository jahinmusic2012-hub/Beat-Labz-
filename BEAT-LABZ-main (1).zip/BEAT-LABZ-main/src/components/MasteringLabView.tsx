import React, { useEffect, useRef, useState } from 'react';
import { Download, Play, Square, Sparkles, CheckCircle2, AlertTriangle } from 'lucide-react';
import type { MasteringMetrics, MasteringSettings, StudioProject } from '../types/studio';
import { MASTERING_PRESETS } from '../data/defaultStudio';
import { audioEngine } from '../audio/audioEngine';
import {
  analyzeStereoBuffer,
  computeParametricEqResponseDb,
  encodeMp3Buffer,
  encodeWavBuffer,
} from '../utils/audioExport';
import { apiUrl } from '../utils/apiClient';

interface MasteringLabViewProps {
  project: StudioProject;
  onUpdateMastering: (next: MasteringSettings) => void;
  onExportComplete: (asset: {
    id: string;
    name: string;
    format: 'WAV' | 'MP3';
    sizeBytes: number;
    objectUrl?: string;
    blobUrl: string;
  }) => void;
}

export const MasteringLabView: React.FC<MasteringLabViewProps> = ({
  project,
  onUpdateMastering,
  onExportComplete,
}) => {
  const settings = project.mastering;
  const [metrics, setMetrics] = useState<MasteringMetrics | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [previewNode, setPreviewNode] = useState<AudioBufferSourceNode | null>(null);
  const [exportStatus, setExportStatus] = useState<string | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const eqCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const runAnalysis = async () => {
    setIsProcessing(true);
    setExportError(null);
    try {
      const rendered = await audioEngine.renderProjectMixToStereo(
        project.tracks,
        project.bpm,
        2,
        settings,
        project.swing ?? 0
      );
      const analyzed = analyzeStereoBuffer(rendered.left, rendered.right, rendered.sampleRate);
      setMetrics(analyzed);
      return rendered;
    } catch (err) {
      setExportError(err instanceof Error ? err.message : 'DSP analysis failed.');
      return null;
    } finally {
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    void runAnalysis();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project.id, project.bpm, project.swing, settings]);

  // Draw logarithmic 20 Hz - 20 kHz Parametric EQ Curve + Crossover Markers
  useEffect(() => {
    const canvas = eqCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#0B0D12';
    ctx.fillRect(0, 0, w, h);

    const minF = Math.log10(20);
    const maxF = Math.log10(20000);
    const freqToX = (f: number) => ((Math.log10(f) - minF) / (maxF - minF)) * w;
    const dbToY = (db: number) => h / 2 - (db / 12) * (h * 0.42);

    // Calibrated dB grid lines
    ctx.lineWidth = 1;
    [-9, -6, -3, 0, 3, 6, 9].forEach((db) => {
      const y = dbToY(db);
      ctx.strokeStyle = db === 0 ? 'rgba(255,255,255,0.16)' : 'rgba(255,255,255,0.05)';
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    });

    // Frequency tick lines & multiband crossovers
    [50, 100, 220, 500, 1000, 3200, 10000].forEach((f) => {
      const x = freqToX(f);
      const isCrossover = f === 220 || f === 3200;
      ctx.strokeStyle = isCrossover ? 'rgba(16, 185, 129, 0.28)' : 'rgba(255,255,255,0.05)';
      ctx.setLineDash(isCrossover ? [4, 4] : []);
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
      ctx.setLineDash([]);
    });

    const sampleCount = 140;
    const freqs: number[] = [];
    for (let i = 0; i < sampleCount; i++) {
      const logF = minF + (i / (sampleCount - 1)) * (maxF - minF);
      freqs.push(Math.pow(10, logF));
    }
    const gains = computeParametricEqResponseDb(settings, 44100, freqs);

    // Fill area under EQ curve relative to 0 dB
    ctx.beginPath();
    ctx.moveTo(0, dbToY(0));
    gains.forEach((g, idx) => {
      const x = (idx / (sampleCount - 1)) * w;
      ctx.lineTo(x, dbToY(Math.max(-11.5, Math.min(11.5, g))));
    });
    ctx.lineTo(w, dbToY(0));
    ctx.closePath();
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, 'rgba(245, 158, 11, 0.28)');
    grad.addColorStop(0.5, 'rgba(245, 158, 11, 0.08)');
    grad.addColorStop(1, 'rgba(56, 189, 248, 0.2)');
    ctx.fillStyle = grad;
    ctx.fill();

    // Stroke sharp EQ response curve
    ctx.beginPath();
    gains.forEach((g, idx) => {
      const x = (idx / (sampleCount - 1)) * w;
      const y = dbToY(Math.max(-11.5, Math.min(11.5, g)));
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Control node dots
    [
      { f: settings.lowFreqHz, g: settings.lowGainDb },
      { f: settings.midFreqHz, g: settings.midGainDb },
      { f: settings.highFreqHz, g: settings.highGainDb },
    ].forEach((pt) => {
      const x = freqToX(pt.f);
      const y = dbToY(Math.max(-11.5, Math.min(11.5, pt.g)));
      ctx.fillStyle = '#0B0D12';
      ctx.strokeStyle = '#FBBF24';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    });
  }, [settings]);

  const togglePreview = async () => {
    if (isPreviewing && previewNode) {
      previewNode.stop();
      setPreviewNode(null);
      setIsPreviewing(false);
      return;
    }
    const rendered = await runAnalysis();
    if (!rendered) return;
    const node = audioEngine.playStereoBuffer(rendered.left, rendered.right, rendered.sampleRate);
    node.onended = () => {
      setIsPreviewing(false);
      setPreviewNode(null);
    };
    setPreviewNode(node);
    setIsPreviewing(true);
  };

  const handleExport = async (format: 'WAV' | 'MP3') => {
    setExportStatus(`Rendering mastered ${format}...`);
    setExportError(null);
    try {
      const rendered = await audioEngine.renderProjectMixToStereo(
        project.tracks,
        project.bpm,
        2,
        settings,
        project.swing ?? 0
      );
      const bytes =
        format === 'WAV'
          ? encodeWavBuffer([rendered.left, rendered.right], rendered.sampleRate)
          : encodeMp3Buffer([rendered.left, rendered.right], rendered.sampleRate, 192);

      const mime = format === 'WAV' ? 'audio/wav' : 'audio/mpeg';
      const ext = format === 'WAV' ? 'wav' : 'mp3';
      const fileName = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-master.${ext}`;
      const blob = new Blob([new Uint8Array(bytes)], { type: mime });
      const blobUrl = URL.createObjectURL(blob);

      // Trigger browser file download
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = fileName;
      a.click();

      // Upload copy to object storage so Connect & Cloud Studio can share it cleanly
      let objectUrl: string | undefined;
      try {
        let binary = '';
        for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
        const res = await fetch(apiUrl('/api/audio-objects'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName,
            mimeType: mime,
            base64Data: btoa(binary),
            projectId: project.id,
            uploader: 'Mastering Lab',
          }),
        });
        if (res.ok) {
          const uploaded = await res.json();
          objectUrl = uploaded.url;
        }
      } catch {
        // Local download still succeeded even if offline
      }

      onExportComplete({
        id: `exp_${Date.now()}`,
        name: fileName,
        format,
        sizeBytes: bytes.byteLength,
        objectUrl,
        blobUrl,
      });

      setExportStatus(`${format} export ready (${(bytes.byteLength / 1024).toFixed(1)} KB).`);
    } catch (err) {
      setExportError(err instanceof Error ? err.message : `Failed to export ${format}.`);
      setExportStatus(null);
    }
  };

  const updateSetting = <K extends keyof MasteringSettings>(key: K, val: MasteringSettings[K]) => {
    onUpdateMastering({ ...settings, presetName: 'Custom', [key]: val });
  };

  return (
    <div className="space-y-6">
      {/* Header & Presets */}
      <div className="studio-rack rounded-xl p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-xl font-bold text-zinc-100">Mastering Lab</h1>
          <p className="text-sm text-zinc-400">
            Parametric EQ, 3-Band Multiband Compression, Stereo Matrix, True-Peak Limiter & Real WAV/MP3 Export
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {Object.keys(MASTERING_PRESETS).map((presetKey) => (
            <button
              key={presetKey}
              type="button"
              onClick={() => onUpdateMastering(MASTERING_PRESETS[presetKey])}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                settings.presetName === presetKey
                  ? 'bg-amber-500 text-zinc-950 border-amber-400'
                  : 'bg-[#191C24] text-zinc-300 border-zinc-700 hover:border-zinc-500'
              }`}
            >
              {presetKey}
            </button>
          ))}
        </div>
      </div>

      {/* Loudness, Peak, Clipping & Stereo Correlation Metering */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="studio-rack rounded-xl p-4">
          <div className="text-xs text-zinc-400">Integrated Loudness</div>
          <div className="text-2xl font-mono font-bold text-amber-400 tabular-nums mt-1">
            {metrics ? `${metrics.lufs} LUFS` : '--'}
          </div>
        </div>
        <div className="studio-rack rounded-xl p-4">
          <div className="text-xs text-zinc-400">True Peak</div>
          <div className="text-2xl font-mono font-bold text-zinc-100 tabular-nums mt-1">
            {metrics ? `${metrics.truePeakDb} dBTP` : '--'}
          </div>
        </div>
        <div className="studio-rack rounded-xl p-4">
          <div className="text-xs text-zinc-400">RMS Level</div>
          <div className="text-2xl font-mono font-bold text-zinc-100 tabular-nums mt-1">
            {metrics ? `${metrics.rmsDb} dBFS` : '--'}
          </div>
        </div>
        <div className="studio-rack rounded-xl p-4">
          <div className="text-xs text-zinc-400">Stereo Correlation</div>
          <div className="text-2xl font-mono font-bold text-emerald-400 tabular-nums mt-1">
            {metrics ? `+${metrics.correlation}` : '--'}
          </div>
        </div>
        <div className="studio-rack rounded-xl p-4 col-span-2 md:col-span-1">
          <div className="text-xs text-zinc-400">Clipping Guard</div>
          <div className="mt-1 flex items-center gap-1.5">
            {metrics && metrics.clippedSamples > 0 ? (
              <span className="text-sm font-mono font-semibold text-red-400 flex items-center gap-1">
                <AlertTriangle className="w-4 h-4" /> {metrics.clippedSamples} clips
              </span>
            ) : (
              <span className="text-sm font-mono font-semibold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> 0 Clips Safe
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Live Parametric EQ & Crossover Response Analyzer */}
      <div className="studio-rack rounded-xl p-4 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-400">
          <span className="font-medium text-zinc-300">Parametric EQ Transfer Curve & 3-Band Crossovers</span>
          <span className="font-mono tabular-nums">20 Hz – 20 kHz · Crossovers: 220 Hz / 3.2 kHz</span>
        </div>
        <canvas
          ref={eqCanvasRef}
          data-testid="mastering-eq-curve"
          width={960}
          height={136}
          className="w-full h-[136px] rounded-lg studio-well"
        />
        <div className="flex justify-between text-[11px] font-mono text-zinc-500 px-1 tabular-nums">
          <span>20 Hz</span>
          <span>100 Hz</span>
          <span>220 Hz</span>
          <span>1 kHz</span>
          <span>3.2 kHz</span>
          <span>10 kHz</span>
          <span>20 kHz</span>
        </div>
      </div>

      {/* DSP Rack: Parametric EQ + Multiband Compressor + Limiter/Stereo */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Parametric EQ */}
        <div className="studio-rack rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">3-Band Parametric EQ</h2>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Low Shelf ({settings.lowFreqHz} Hz)</span>
              <span className="font-mono tabular-nums">{settings.lowGainDb > 0 ? `+${settings.lowGainDb}` : settings.lowGainDb} dB</span>
            </div>
            <input
              type="range"
              min={-9}
              max={9}
              step={0.1}
              value={settings.lowGainDb}
              onChange={(e) => updateSetting('lowGainDb', Number(e.target.value))}
              className="w-full studio-slider accent-amber-500"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Mid Bell ({settings.midFreqHz} Hz · Q {settings.midQ})</span>
              <span className="font-mono tabular-nums">{settings.midGainDb > 0 ? `+${settings.midGainDb}` : settings.midGainDb} dB</span>
            </div>
            <input
              type="range"
              min={-9}
              max={9}
              step={0.1}
              value={settings.midGainDb}
              onChange={(e) => updateSetting('midGainDb', Number(e.target.value))}
              className="w-full studio-slider accent-amber-500"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Mid Frequency</span>
              <span className="font-mono tabular-nums">{settings.midFreqHz} Hz</span>
            </div>
            <input
              type="range"
              min={250}
              max={5500}
              step={50}
              value={settings.midFreqHz}
              onChange={(e) => updateSetting('midFreqHz', Number(e.target.value))}
              className="w-full studio-slider accent-zinc-400"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>High Air Shelf ({settings.highFreqHz} Hz)</span>
              <span className="font-mono tabular-nums">{settings.highGainDb > 0 ? `+${settings.highGainDb}` : settings.highGainDb} dB</span>
            </div>
            <input
              type="range"
              min={-9}
              max={9}
              step={0.1}
              value={settings.highGainDb}
              onChange={(e) => updateSetting('highGainDb', Number(e.target.value))}
              className="w-full studio-slider accent-amber-500"
            />
          </label>
        </div>

        {/* Multiband Compressor */}
        <div className="studio-rack rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">Multiband Compressor</h2>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Low Band Thresh (&lt;220 Hz)</span>
              <span className="font-mono tabular-nums">{settings.lowBandThresholdDb} dB</span>
            </div>
            <input
              type="range"
              min={-36}
              max={-4}
              step={1}
              value={settings.lowBandThresholdDb}
              onChange={(e) => updateSetting('lowBandThresholdDb', Number(e.target.value))}
              className="w-full studio-slider accent-emerald-500"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Mid Band Thresh (220–3.2k Hz)</span>
              <span className="font-mono tabular-nums">{settings.midBandThresholdDb} dB</span>
            </div>
            <input
              type="range"
              min={-36}
              max={-4}
              step={1}
              value={settings.midBandThresholdDb}
              onChange={(e) => updateSetting('midBandThresholdDb', Number(e.target.value))}
              className="w-full studio-slider accent-emerald-500"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>High Band Thresh (&gt;3.2k Hz)</span>
              <span className="font-mono tabular-nums">{settings.highBandThresholdDb} dB</span>
            </div>
            <input
              type="range"
              min={-36}
              max={-4}
              step={1}
              value={settings.highBandThresholdDb}
              onChange={(e) => updateSetting('highBandThresholdDb', Number(e.target.value))}
              className="w-full studio-slider accent-emerald-500"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Ratio</span>
              <span className="font-mono tabular-nums">{settings.compRatio}:1</span>
            </div>
            <input
              type="range"
              min={1.2}
              max={8}
              step={0.1}
              value={settings.compRatio}
              onChange={(e) => updateSetting('compRatio', Number(e.target.value))}
              className="w-full studio-slider accent-emerald-500"
            />
          </label>
        </div>

        {/* Limiter, Stereo Width & Real Export */}
        <div className="studio-rack rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">Stereo Field & Brickwall Limiter</h2>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Stereo Width (M/S)</span>
              <span className="font-mono tabular-nums">{Math.round(settings.stereoWidth * 100)}%</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={1.6}
              step={0.02}
              value={settings.stereoWidth}
              onChange={(e) => updateSetting('stereoWidth', Number(e.target.value))}
              className="w-full studio-slider accent-sky-400"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Makeup Gain</span>
              <span className="font-mono tabular-nums">+{settings.makeupGainDb} dB</span>
            </div>
            <input
              type="range"
              min={0}
              max={10}
              step={0.2}
              value={settings.makeupGainDb}
              onChange={(e) => updateSetting('makeupGainDb', Number(e.target.value))}
              className="w-full studio-slider accent-amber-500"
            />
          </label>
          <label className="block space-y-1">
            <div className="flex justify-between text-xs text-zinc-400">
              <span>Limiter Ceiling</span>
              <span className="font-mono tabular-nums">{settings.limiterCeilingDb} dBTP</span>
            </div>
            <input
              type="range"
              min={-3.0}
              max={-0.1}
              step={0.1}
              value={settings.limiterCeilingDb}
              onChange={(e) => updateSetting('limiterCeilingDb', Number(e.target.value))}
              className="w-full studio-slider accent-red-400"
            />
          </label>

          <div className="pt-2 space-y-2">
            <button
              type="button"
              onClick={togglePreview}
              disabled={isProcessing}
              className="w-full py-2.5 px-4 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-sm font-medium text-zinc-100 flex items-center justify-center gap-2"
            >
              {isPreviewing ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
              {isPreviewing ? 'Stop Master Preview' : 'Audition Mastered Mix'}
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleExport('WAV')}
                className="py-2.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-4 h-4" /> Export WAV
              </button>
              <button
                type="button"
                onClick={() => handleExport('MP3')}
                className="py-2.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-sm font-semibold flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" /> Export MP3
              </button>
            </div>

            {exportStatus && <p className="text-xs text-emerald-400">{exportStatus}</p>}
            {exportError && <p className="text-xs text-red-400">{exportError}</p>}
          </div>
        </div>
      </div>
    </div>
  );
};
