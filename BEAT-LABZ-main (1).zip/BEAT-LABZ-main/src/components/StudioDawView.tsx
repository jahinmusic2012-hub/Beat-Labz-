import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  Square,
  Plus,
  Trash2,
  Volume2,
  VolumeX,
  Sliders,
  Music,
  BookOpen,
  Download,
  Upload,
  RotateCcw,
  Sparkles,
  ArrowLeft,
  ArrowRight,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import type { ChordChartItem, RecordedTake, SequencerTrack, StudioProject } from '../types/studio';
import { audioEngine } from '../audio/audioEngine';
import { PROJECT_TEMPLATES, type ProjectTemplateSpec } from '../data/defaultStudio';
import {
  buildMidiFileBytes,
  generateEuclideanSteps,
  midiToNoteName,
  parseChordSymbol,
  shiftStepArray,
  transposeChordSymbol,
} from '../utils/musicTheory';
import { formatBytes } from '../utils/shareUtils';
import { apiUrl } from '../utils/apiClient';

interface StudioDawViewProps {
  project: StudioProject;
  onUpdateProject: (updater: (prev: StudioProject) => StudioProject) => void;
  currentStep: number;
  isPlaying: boolean;
  recordings: RecordedTake[];
  onAddRecording: (rec: RecordedTake) => void;
  onDeleteRecording: (id: string) => void;
  savedProjects: StudioProject[];
  onSelectProject: (p: StudioProject) => void;
  onCreateNewProject: (template?: ProjectTemplateSpec) => void;
  onOpenConnectForShare: () => void;
  canUndo?: boolean;
  onUndo?: () => void;
}

const DRUM_LABELS = ['Kick', 'Snare', 'Cl Hat', 'Op Hat', 'Clap', 'Tom'];
const SYNTH_KEYS = [
  { midi: 60, label: 'C4', sharp: false },
  { midi: 61, label: 'C#4', sharp: true },
  { midi: 62, label: 'D4', sharp: false },
  { midi: 63, label: 'Eb4', sharp: true },
  { midi: 64, label: 'E4', sharp: false },
  { midi: 65, label: 'F4', sharp: false },
  { midi: 66, label: 'F#4', sharp: true },
  { midi: 67, label: 'G4', sharp: false },
  { midi: 68, label: 'Ab4', sharp: true },
  { midi: 69, label: 'A4', sharp: false },
  { midi: 70, label: 'Bb4', sharp: true },
  { midi: 71, label: 'B4', sharp: false },
  { midi: 72, label: 'C5', sharp: false },
];

export const StudioDawView: React.FC<StudioDawViewProps> = ({
  project,
  onUpdateProject,
  currentStep,
  isPlaying,
  recordings,
  onAddRecording,
  onDeleteRecording,
  savedProjects,
  onSelectProject,
  onCreateNewProject,
  onOpenConnectForShare,
  canUndo = false,
  onUndo,
}) => {
  const [studioSubTab, setStudioSubTab] = useState<'sequencer' | 'instruments' | 'mixer' | 'songbook'>('sequencer');
  const [selectedTrackId, setSelectedTrackId] = useState<string>(project.tracks[0]?.id ?? '');
  const [stepEditMode, setStepEditMode] = useState<'toggle' | 'pitch'>('toggle');
  const [selectedStepIdx, setSelectedStepIdx] = useState<number>(0);
  const [selectedInstrument, setSelectedInstrument] = useState<'warm-synth' | 'electric-piano' | 'worship-pad' | 'sub-bass'>('electric-piano');
  const [isRecordingMic, setIsRecordingMic] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [recordingSec, setRecordingSec] = useState(0);
  const [uploadingRecId, setUploadingRecId] = useState<string | null>(null);
  const [livePeakDb, setLivePeakDb] = useState<number>(-60);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recStartRef = useRef<number>(0);
  const tapTimesRef = useRef<number[]>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const selectedTrack = project.tracks.find((t) => t.id === selectedTrackId) ?? project.tracks[0];

  // Live master Spectrum FFT + Waveform Oscilloscope + Peak dB meter
  useEffect(() => {
    let raf = 0;
    let frame = 0;
    const waveBuf = new Uint8Array(new ArrayBuffer(512));
    const fftBuf = new Uint8Array(new ArrayBuffer(512));

    const draw = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;
          ctx.fillStyle = '#0B0D12';
          ctx.fillRect(0, 0, w, h);

          // Calibrated studio reticle
          ctx.strokeStyle = 'rgba(255,255,255,0.05)';
          ctx.lineWidth = 1;
          [0.25, 0.5, 0.75].forEach((ratio) => {
            ctx.beginPath();
            ctx.moveTo(0, h * ratio);
            ctx.lineTo(w, h * ratio);
            ctx.stroke();
          });

          const hasWave = audioEngine.getAnalyserData(waveBuf);
          const hasFft = audioEngine.getFrequencyData(fftBuf);

          // 48-band FFT Spectrum Bars
          const barCount = 48;
          const barGap = 3;
          const barWidth = (w - barGap * (barCount - 1)) / barCount;
          for (let b = 0; b < barCount; b++) {
            const binIdx = Math.min(fftBuf.length - 1, Math.floor(Math.pow(b / barCount, 1.45) * 180));
            const mag = hasFft ? fftBuf[binIdx] / 255 : 0;
            const barH = Math.max(2, mag * (h - 10));
            const x = b * (barWidth + barGap);
            ctx.fillStyle = mag > 0.78 ? 'rgba(245, 158, 11, 0.42)' : 'rgba(56, 189, 248, 0.22)';
            ctx.fillRect(x, h - barH, barWidth, barH);
          }

          // Center waveform trace
          ctx.strokeStyle = isPlaying || isRecordingMic ? '#F59E0B' : '#52525B';
          ctx.lineWidth = 2;
          ctx.beginPath();
          for (let i = 0; i < waveBuf.length; i++) {
            const x = (i / (waveBuf.length - 1)) * w;
            const y = hasWave ? (waveBuf[i] / 255) * h : h / 2;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();

          if (frame % 6 === 0) {
            setLivePeakDb(audioEngine.getOutputPeakDb());
          }
          frame++;
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [isPlaying, isRecordingMic]);

  // Recording timer
  useEffect(() => {
    if (!isRecordingMic) return;
    const id = setInterval(() => {
      setRecordingSec(Math.floor((Date.now() - recStartRef.current) / 1000));
    }, 250);
    return () => clearInterval(id);
  }, [isRecordingMic]);

  const toggleStep = (trackId: string, stepIndex: number) => {
    audioEngine.ensureContext();
    onUpdateProject((prev) => ({
      ...prev,
      tracks: prev.tracks.map((trk) => {
        if (trk.id !== trackId) return trk;
        const nextSteps = [...trk.steps];
        nextSteps[stepIndex] = !nextSteps[stepIndex];
        return { ...trk, steps: nextSteps };
      }),
    }));
  };

  const updateTrackField = (trackId: string, patch: Partial<SequencerTrack>) => {
    onUpdateProject((prev) => ({
      ...prev,
      tracks: prev.tracks.map((t) => (t.id === trackId ? { ...t, ...patch } : t)),
    }));
  };

  const addMelodicTrack = () => {
    const id = `trk_${Date.now()}`;
    const newTrack: SequencerTrack = {
      id,
      name: `Lead Synth ${project.tracks.length + 1}`,
      kind: 'synth',
      color: '#EC4899',
      volume: 0.75,
      pan: 0,
      muted: false,
      solo: false,
      eqLow: 0,
      eqHigh: 0,
      reverbSend: 0.25,
      steps: Array.from({ length: 16 }, (_, i) => i % 4 === 0),
      notes: Array.from({ length: 16 }, () => 60),
      instrumentPreset: 'warm-synth',
    };
    onUpdateProject((prev) => ({ ...prev, tracks: [...prev.tracks, newTrack] }));
    setSelectedTrackId(id);
  };

  const startMicRecording = async () => {
    setMicError(null);
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setMicError('Microphone recording is not supported in this browser context.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;
      chunksRef.current = [];
      const candidateMimes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/mp4',
      ];
      const supportedMime =
        typeof MediaRecorder.isTypeSupported === 'function'
          ? candidateMimes.find((m) => MediaRecorder.isTypeSupported(m))
          : undefined;
      const recorder = supportedMime
        ? new MediaRecorder(stream, { mimeType: supportedMime })
        : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };

      recorder.onstop = async () => {
        const resolvedMime = recorder.mimeType || supportedMime || 'audio/webm';
        const blob = new Blob(chunksRef.current, { type: resolvedMime });
        const localUrl = URL.createObjectURL(blob);
        const dur = Math.max(1, (Date.now() - recStartRef.current) / 1000);
        const newRec: RecordedTake = {
          id: `rec_${Date.now()}`,
          name: `${project.title} Take ${recordings.length + 1}`,
          durationSec: Number(dur.toFixed(1)),
          sampleRate: 44100,
          createdAt: new Date().toISOString(),
          mimeType: blob.type || resolvedMime,
          sizeBytes: blob.size,
          localBlobUrl: localUrl,
          waveformPeaks: Array.from({ length: 24 }, (_, i) => 0.25 + ((i * 7 + blob.size) % 70) / 100),
        };
        onAddRecording(newRec);
        stream.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
      };

      recStartRef.current = Date.now();
      setRecordingSec(0);
      recorder.start();
      setIsRecordingMic(true);
    } catch (err) {
      setMicError(err instanceof Error ? err.message : 'Microphone permission denied.');
    }
  };

  const stopMicRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecordingMic(false);
  };

  const uploadRecordingToObjectStorage = async (rec: RecordedTake) => {
    if (!rec.localBlobUrl) return;
    setUploadingRecId(rec.id);
    try {
      const blob = await fetch(rec.localBlobUrl).then((r) => r.blob());
      const arrayBuf = await blob.arrayBuffer();
      const bytes = new Uint8Array(arrayBuf);
      let binary = '';
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      const base64Data = btoa(binary);
      const cleanMime = rec.mimeType.split(';')[0] || 'audio/webm';
      const ext = cleanMime.includes('mp4') ? 'mp4' : cleanMime.includes('ogg') ? 'ogg' : 'webm';

      const res = await fetch(apiUrl('/api/audio-objects'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: `${rec.name.replace(/\s+/g, '_')}.${ext}`,
          mimeType: cleanMime,
          base64Data,
          projectId: project.id,
          uploader: 'Studio Recorder',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      onAddRecording({ ...rec, objectUrl: data.url });
    } catch (err) {
      setMicError(err instanceof Error ? err.message : 'Failed to back up recording.');
    } finally {
      setUploadingRecId(null);
    }
  };

  const downloadMidi = () => {
    const midiBytes = buildMidiFileBytes(project.tracks, project.bpm);
    const blob = new Blob([new Uint8Array(midiBytes)], { type: 'audio/midi' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.mid`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const addChordSection = () => {
    const newItem: ChordChartItem = {
      id: `cc_${Date.now()}`,
      section: 'Bridge',
      chords: ['Am7', 'Fmaj7', 'C', 'G'],
      lyrics: 'Build dynamics gradually over 8 bars',
      bars: 8,
    };
    onUpdateProject((prev) => ({ ...prev, chordChart: [...prev.chordChart, newItem] }));
  };

  const transposeProject = (semitones: number) => {
    onUpdateProject((prev) => ({
      ...prev,
      musicalKey: transposeChordSymbol(prev.musicalKey.split(' ')[0], semitones) + (prev.musicalKey.includes('Minor') ? ' Minor' : ' Major'),
      chordChart: prev.chordChart.map((section) => ({
        ...section,
        chords: section.chords.map((c) => transposeChordSymbol(c, semitones)),
      })),
      tracks: prev.tracks.map((t) =>
        t.kind === 'drums'
          ? t
          : { ...t, notes: t.notes.map((n) => Math.max(24, Math.min(96, n + semitones))) }
      ),
    }));
  };

  const playChordSection = (chords: string[]) => {
    const beatSec = 60 / Math.max(40, project.bpm);
    chords.forEach((ch, idx) => {
      setTimeout(() => {
        const parsed = parseChordSymbol(ch, 4);
        audioEngine.triggerChord(parsed.midis, beatSec * 1.6, 'electric-piano');
      }, idx * beatSec * 2000);
    });
  };

  const handleTapTempo = () => {
    const now = performance.now();
    const recent = tapTimesRef.current.filter((t) => now - t < 2500);
    recent.push(now);
    tapTimesRef.current = recent;
    if (recent.length >= 2) {
      const diffs: number[] = [];
      for (let i = 1; i < recent.length; i++) diffs.push(recent[i] - recent[i - 1]);
      const avgMs = diffs.reduce((a, b) => a + b, 0) / diffs.length;
      const bpm = Math.max(40, Math.min(240, Math.round(60000 / avgMs)));
      onUpdateProject((prev) => ({ ...prev, bpm }));
    }
  };

  const applyPatternEuclidean = (pulses: number) => {
    if (!selectedTrack) return;
    updateTrackField(selectedTrack.id, { steps: generateEuclideanSteps(pulses, 16) });
  };

  const shiftSelectedTrack = (delta: number) => {
    if (!selectedTrack) return;
    updateTrackField(selectedTrack.id, {
      steps: shiftStepArray(selectedTrack.steps, delta),
      notes: shiftStepArray(selectedTrack.notes, delta),
    });
  };

  const clearSelectedTrack = () => {
    if (!selectedTrack) return;
    updateTrackField(selectedTrack.id, { steps: Array.from({ length: 16 }, () => false) });
  };

  const adjustSelectedStepPitch = (delta: number) => {
    if (!selectedTrack) return;
    const nextNotes = [...selectedTrack.notes];
    if (selectedTrack.kind === 'drums') {
      const cur = nextNotes[selectedStepIdx] ?? 0;
      nextNotes[selectedStepIdx] = (cur + delta + DRUM_LABELS.length) % DRUM_LABELS.length;
    } else {
      const cur = nextNotes[selectedStepIdx] ?? 60;
      nextNotes[selectedStepIdx] = Math.max(24, Math.min(96, cur + delta));
    }
    updateTrackField(selectedTrack.id, { notes: nextNotes });
  };

  const deleteTrack = (trackId: string) => {
    if (project.tracks.length <= 1) return;
    const remaining = project.tracks.filter((t) => t.id !== trackId);
    onUpdateProject((prev) => ({ ...prev, tracks: remaining }));
    if (selectedTrackId === trackId) setSelectedTrackId(remaining[0].id);
  };

  return (
    <div className="space-y-6 min-w-0">
      {/* Project Header & Sub-Navigation */}
      <div className="studio-rack rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 min-w-0">
            <label htmlFor="project-select" className="sr-only">Active Project</label>
            <select
              id="project-select"
              value={project.id}
              onChange={(e) => {
                const found = savedProjects.find((p) => p.id === e.target.value);
                if (found) onSelectProject(found);
              }}
              className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-sm font-medium text-zinc-100 focus:outline-none focus:ring-2 focus:ring-amber-500 max-w-full"
            >
              {savedProjects.map((p) => (
                <option key={p.id} value={p.id}>{p.title}</option>
              ))}
            </select>
            <input
              type="text"
              aria-label="Project title"
              value={project.title}
              onChange={(e) => onUpdateProject((prev) => ({ ...prev, title: e.target.value }))}
              className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-100 w-40 sm:w-48 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <select
              aria-label="Create project from template"
              defaultValue=""
              onChange={(e) => {
                const tpl = PROJECT_TEMPLATES.find((t) => t.id === e.target.value);
                if (tpl) onCreateNewProject(tpl);
                e.currentTarget.value = '';
              }}
              className="bg-[#191C24] border border-zinc-700 rounded-lg px-2.5 py-2 text-xs text-zinc-300"
            >
              <option value="" disabled>From Template...</option>
              {PROJECT_TEMPLATES.map((tpl) => (
                <option key={tpl.id} value={tpl.id}>
                  {tpl.name} ({tpl.bpm} BPM)
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => onCreateNewProject()}
              className="px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" /> New Project
            </button>
          </div>

          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            {onUndo && (
              <button
                type="button"
                disabled={!canUndo}
                onClick={onUndo}
                title="Undo last edit (Ctrl/Cmd+Z)"
                className="px-2.5 py-2 rounded-lg border border-zinc-700 hover:bg-zinc-800 disabled:opacity-40 text-xs font-medium text-zinc-200 flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Undo
              </button>
            )}
            <button
              type="button"
              onClick={downloadMidi}
              className="px-3 py-2 rounded-lg border border-zinc-700 hover:bg-zinc-800 text-xs font-medium text-zinc-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" /> Export MIDI
            </button>
            <button
              type="button"
              onClick={onOpenConnectForShare}
              className="px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-amber-400 whitespace-nowrap shrink-0"
            >
              Share Project
            </button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="grid grid-cols-2 sm:inline-flex items-center gap-1 p-1 bg-[#0B0D12] rounded-lg border border-zinc-800 w-full sm:w-auto">
            {[
              { id: 'sequencer', label: 'Sequencer', icon: Sliders },
              { id: 'instruments', label: 'Instruments & Mic', icon: Mic },
              { id: 'mixer', label: 'Console Mixer', icon: Volume2 },
              { id: 'songbook', label: 'Chords & Songbook', icon: BookOpen },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStudioSubTab(tab.id as typeof studioSubTab)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center justify-center sm:justify-start gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                  studioSubTab === tab.id
                    ? 'bg-amber-500 text-zinc-950'
                    : 'text-zinc-400 hover:text-zinc-100'
                }`}
              >
                <tab.icon className="w-3.5 h-3.5 shrink-0" />
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 text-xs text-zinc-400">
            <button
              type="button"
              onClick={handleTapTempo}
              className="px-2.5 py-1.5 rounded-md bg-[#191C24] border border-zinc-700 hover:border-amber-500 text-zinc-200 font-medium whitespace-nowrap shrink-0"
            >
              Tap Tempo
            </button>
            <label className="flex items-center gap-2 whitespace-nowrap shrink-0">
              <span>Swing</span>
              <input
                type="range"
                aria-label="Master Swing Percentage"
                min={0}
                max={60}
                step={2}
                value={project.swing ?? 0}
                onChange={(e) => onUpdateProject((prev) => ({ ...prev, swing: Number(e.target.value) }))}
                className="w-20 studio-slider accent-amber-500"
              />
              <span className="font-mono text-amber-400 tabular-nums w-8">{project.swing ?? 0}%</span>
            </label>
          </div>
        </div>
      </div>

      {/* Live Master Spectrum FFT + Waveform Oscilloscope */}
      <div className="studio-rack rounded-xl p-4 min-w-0">
        <div className="flex items-center justify-between gap-2 mb-2">
          <span className="text-xs font-medium text-zinc-400 truncate">
            Master Spectrum & Oscilloscope · {project.musicalKey} · {project.bpm} BPM · {project.timeSignature}
          </span>
          <div className="flex items-center gap-3 text-xs font-mono text-zinc-400 tabular-nums whitespace-nowrap shrink-0">
            <span className={livePeakDb > -1 ? 'text-red-400 font-semibold' : 'text-emerald-400'}>
              Peak {livePeakDb <= -59 ? '-∞' : livePeakDb.toFixed(1)} dB
            </span>
            <span>Step {String(currentStep + 1).padStart(2, '0')} / 16</span>
          </div>
        </div>
        <canvas
          ref={canvasRef}
          data-testid="daw-oscilloscope"
          width={960}
          height={96}
          className="w-full h-[96px] rounded-lg studio-well"
        />
      </div>

      {studioSubTab === 'sequencer' && (
        <div className="studio-rack rounded-xl p-4 space-y-4 min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold text-zinc-100">16-Step Pattern Sequencer</h2>
              <p className="text-xs text-zinc-400">
                Selected Track: <span className="text-amber-400 font-medium">{selectedTrack?.name}</span> ·{' '}
                {stepEditMode === 'toggle' ? 'Click pads to toggle hits' : `Editing Step ${selectedStepIdx + 1} pitch/voice`}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1 p-0.5 bg-[#0B0D12] rounded-lg border border-zinc-800">
                <button
                  type="button"
                  onClick={() => setStepEditMode('toggle')}
                  className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap ${
                    stepEditMode === 'toggle' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400'
                  }`}
                >
                  Toggle Steps
                </button>
                <button
                  type="button"
                  onClick={() => setStepEditMode('pitch')}
                  className={`px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap ${
                    stepEditMode === 'pitch' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400'
                  }`}
                >
                  Edit Note / Hit
                </button>
              </div>
              <button
                type="button"
                onClick={addMelodicTrack}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-100 flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Plus className="w-3.5 h-3.5" /> Add Synth Track
              </button>
            </div>
          </div>

          {/* Selected Track Pattern Tools & Step Pitch Inspector */}
          {selectedTrack && (
            <div className="studio-well rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                {selectedTrack.kind !== 'drums' && (
                  <select
                    aria-label="Track instrument preset"
                    value={selectedTrack.instrumentPreset}
                    onChange={(e) => updateTrackField(selectedTrack.id, { instrumentPreset: e.target.value })}
                    className="bg-[#191C24] border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200"
                  >
                    <option value="electric-piano">Electric Piano</option>
                    <option value="warm-synth">Warm Analog Synth</option>
                    <option value="worship-pad">Worship Shimmer Pad</option>
                    <option value="sub-bass">Sub Synth Bass</option>
                  </select>
                )}
                <button
                  type="button"
                  onClick={() => applyPatternEuclidean(4)}
                  className="px-2 py-1 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-300 flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" /> Euc 4
                </button>
                <button
                  type="button"
                  onClick={() => applyPatternEuclidean(5)}
                  className="px-2 py-1 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-300"
                >
                  Euc 5
                </button>
                <button
                  type="button"
                  onClick={() => applyPatternEuclidean(8)}
                  className="px-2 py-1 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-300"
                >
                  Euc 8
                </button>
                <button
                  type="button"
                  aria-label="Shift pattern left"
                  onClick={() => shiftSelectedTrack(-1)}
                  className="p-1.5 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-300"
                >
                  <ArrowLeft className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  aria-label="Shift pattern right"
                  onClick={() => shiftSelectedTrack(1)}
                  className="p-1.5 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-300"
                >
                  <ArrowRight className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={clearSelectedTrack}
                  className="px-2 py-1 rounded bg-[#191C24] hover:bg-red-500/20 border border-zinc-700 text-zinc-300 hover:text-red-300"
                >
                  Clear
                </button>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-zinc-400 font-mono tabular-nums">
                  Step #{selectedStepIdx + 1}:{' '}
                  <strong className="text-amber-400">
                    {selectedTrack.kind === 'drums'
                      ? DRUM_LABELS[selectedTrack.notes[selectedStepIdx] ?? 0]
                      : midiToNoteName(selectedTrack.notes[selectedStepIdx] ?? 60)}
                  </strong>
                </span>
                <button
                  type="button"
                  aria-label="Lower step pitch or drum voice"
                  onClick={() => adjustSelectedStepPitch(-1)}
                  className="p-1 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-200"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label="Raise step pitch or drum voice"
                  onClick={() => adjustSelectedStepPitch(1)}
                  className="p-1 rounded bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-zinc-200"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          <div className="space-y-3 overflow-x-auto pb-2 w-full">
            {project.tracks.map((track) => (
              <div
                key={track.id}
                className={`min-w-[780px] p-3 rounded-lg border transition-colors ${
                  selectedTrack?.id === track.id
                    ? 'bg-[#191C24] border-amber-500/40'
                    : 'bg-[#0E1015] border-zinc-800/80'
                }`}
              >
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedTrackId(track.id)}
                    className="w-36 text-left shrink-0"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: track.color }} />
                      <span className="text-sm font-medium text-zinc-100 truncate">{track.name}</span>
                    </div>
                    <span className="text-[11px] text-zinc-500">{track.kind} · {track.instrumentPreset}</span>
                  </button>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      aria-label={`Mute ${track.name}`}
                      onClick={() => updateTrackField(track.id, { muted: !track.muted })}
                      className={`w-8 h-8 rounded text-xs font-semibold ${
                        track.muted ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'bg-zinc-800 text-zinc-400 hover:text-zinc-100'
                      }`}
                    >
                      M
                    </button>
                    <button
                      type="button"
                      aria-label={`Solo ${track.name}`}
                      onClick={() => updateTrackField(track.id, { solo: !track.solo })}
                      className={`w-8 h-8 rounded text-xs font-semibold ${
                        track.solo ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-zinc-800 text-zinc-400 hover:text-zinc-100'
                      }`}
                    >
                      S
                    </button>
                    {project.tracks.length > 1 && (
                      <button
                        type="button"
                        aria-label={`Delete track ${track.name}`}
                        onClick={() => deleteTrack(track.id)}
                        className="w-7 h-8 rounded text-zinc-500 hover:text-red-400 flex items-center justify-center"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-[repeat(16,minmax(0,1fr))] gap-1.5 flex-1">
                    {track.steps.map((active, stepIdx) => {
                      const isCurrent = isPlaying && currentStep === stepIdx;
                      const isBeatStart = stepIdx % 4 === 0;
                      const isSelectedStep = selectedTrack?.id === track.id && selectedStepIdx === stepIdx;
                      return (
                        <button
                          key={stepIdx}
                          type="button"
                          aria-label={`${track.name} step ${stepIdx + 1}`}
                          aria-pressed={active}
                          onClick={() => {
                            setSelectedTrackId(track.id);
                            setSelectedStepIdx(stepIdx);
                            if (stepEditMode === 'toggle') {
                              toggleStep(track.id, stepIdx);
                            } else if (track.kind === 'drums') {
                              const nextNotes = [...track.notes];
                              nextNotes[stepIdx] = ((nextNotes[stepIdx] ?? 0) + 1) % DRUM_LABELS.length;
                              updateTrackField(track.id, { notes: nextNotes });
                            }
                          }}
                          className={`h-10 rounded-md border text-[10px] font-mono transition-all ${
                            active
                              ? 'border-transparent text-zinc-950 font-semibold'
                              : isBeatStart
                                ? 'bg-[#171A22] border-zinc-700/80 text-zinc-500 hover:border-zinc-500'
                                : 'bg-[#111319] border-zinc-800 text-zinc-600 hover:border-zinc-600'
                          } ${isCurrent ? 'ring-2 ring-white/80 scale-[1.03]' : ''} ${isSelectedStep ? 'outline outline-1 outline-amber-400' : ''}`}
                          style={active ? { backgroundColor: track.color } : undefined}
                        >
                          {track.kind === 'drums'
                            ? DRUM_LABELS[track.notes[stepIdx] ?? 0]?.slice(0, 2)
                            : midiToNoteName(track.notes[stepIdx] ?? 60)}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {studioSubTab === 'instruments' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Drum Pads + Synth Keys */}
          <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-zinc-100">Live Instruments & Drum Pads</h2>
              <select
                aria-label="Synth Instrument Preset"
                value={selectedInstrument}
                onChange={(e) => setSelectedInstrument(e.target.value as typeof selectedInstrument)}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-2.5 py-1.5 text-xs text-zinc-200"
              >
                <option value="electric-piano">Electric Piano</option>
                <option value="warm-synth">Warm Analog Synth</option>
                <option value="worship-pad">Worship Shimmer Pad</option>
                <option value="sub-bass">Sub Synth Bass</option>
              </select>
            </div>

            <div>
              <div className="text-xs text-zinc-400 mb-2">Studio Drum Kit (Touch Pads)</div>
              <div className="grid grid-cols-3 gap-2.5">
                {DRUM_LABELS.map((label, idx) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => audioEngine.triggerDrumVoice(idx, 0.9, 0)}
                    className="h-14 rounded-xl bg-[#191C24] hover:bg-amber-500/20 border border-zinc-700 hover:border-amber-500 text-sm font-medium text-zinc-100 active:scale-[0.98] transition-all"
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-xs text-zinc-400 mb-2">Polyphonic Keyboard (C4 – C5)</div>
              <div className="studio-well rounded-xl p-2.5 overflow-x-auto">
                <div className="relative h-32 min-w-[400px] select-none">
                  <div className="grid grid-cols-8 gap-1 h-full">
                    {SYNTH_KEYS.filter((k) => !k.sharp).map((k) => (
                      <button
                        key={k.midi}
                        type="button"
                        onClick={() =>
                          audioEngine.triggerNote(k.midi, {
                            preset: selectedInstrument,
                            durationSec: 0.45,
                            reverbSend: 0.3,
                          })
                        }
                        className="h-full rounded-b-lg rounded-t-sm border border-zinc-400 bg-gradient-to-b from-zinc-100 to-zinc-200 hover:from-white hover:to-amber-100 text-zinc-900 text-xs font-mono flex flex-col justify-end items-center pb-2 active:translate-y-[1px]"
                      >
                        {k.label}
                      </button>
                    ))}
                  </div>
                  {[
                    { midi: 61, label: 'C#4', leftPct: 9.1 },
                    { midi: 63, label: 'Eb4', leftPct: 21.6 },
                    { midi: 66, label: 'F#4', leftPct: 46.6 },
                    { midi: 68, label: 'Ab4', leftPct: 59.1 },
                    { midi: 70, label: 'Bb4', leftPct: 71.6 },
                  ].map((k) => (
                    <button
                      key={k.midi}
                      type="button"
                      onClick={() =>
                        audioEngine.triggerNote(k.midi, {
                          preset: selectedInstrument,
                          durationSec: 0.45,
                          reverbSend: 0.3,
                        })
                      }
                      style={{ left: `${k.leftPct}%`, width: '7.4%' }}
                      className="absolute top-0 h-[58%] rounded-b-md border border-zinc-700 bg-gradient-to-b from-zinc-800 to-zinc-950 hover:border-amber-500 text-amber-400 text-[10px] font-mono flex flex-col justify-end items-center pb-1.5 z-10 shadow-md active:translate-y-[1px]"
                    >
                      {k.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Microphone Audio Recording System */}
          <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-zinc-100">Audio & Vocal Recorder</h2>
              <span className="text-xs font-mono text-zinc-400 tabular-nums">
                {isRecordingMic ? `REC ${recordingSec}s` : `${recordings.length} takes`}
              </span>
            </div>

            {micError && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
                {micError}
              </div>
            )}

            <div className="flex items-center gap-3">
              {!isRecordingMic ? (
                <button
                  type="button"
                  onClick={startMicRecording}
                  className="px-4 py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-medium flex items-center gap-2"
                >
                  <Mic className="w-4 h-4" /> Record Audio Take
                </button>
              ) : (
                <button
                  type="button"
                  onClick={stopMicRecording}
                  className="px-4 py-2.5 rounded-lg bg-zinc-100 text-zinc-950 text-sm font-semibold flex items-center gap-2"
                >
                  <Square className="w-4 h-4 fill-current" /> Stop Recording ({recordingSec}s)
                </button>
              )}
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {recordings.length === 0 ? (
                <div className="p-6 text-center border border-dashed border-zinc-800 rounded-lg text-xs text-zinc-500">
                  No audio takes recorded yet. Record vocals or acoustic instruments above.
                </div>
              ) : (
                recordings.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-zinc-100 truncate">{rec.name}</div>
                      <div className="text-xs text-zinc-400 tabular-nums">
                        {rec.durationSec}s · {formatBytes(rec.sizeBytes)} {rec.objectUrl ? '· Cloud Object Backed Up' : '· Local Take'}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {(rec.localBlobUrl || rec.objectUrl) && (
                        <audio controls src={rec.objectUrl || rec.localBlobUrl} className="h-8 max-w-[180px]" />
                      )}
                      {!rec.objectUrl && rec.localBlobUrl && (
                        <button
                          type="button"
                          disabled={uploadingRecId === rec.id}
                          onClick={() => uploadRecordingToObjectStorage(rec)}
                          className="px-2.5 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-xs text-amber-400 flex items-center gap-1"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          {uploadingRecId === rec.id ? 'Saving...' : 'Back Up'}
                        </button>
                      )}
                      <button
                        type="button"
                        aria-label={`Delete ${rec.name}`}
                        onClick={() => onDeleteRecording(rec.id)}
                        className="p-1.5 rounded text-zinc-400 hover:text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {studioSubTab === 'mixer' && (
        <div className="studio-rack rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">Channel Strip Console Mixer</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {project.tracks.map((track) => (
              <div key={track.id} className="studio-well rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: track.color }} />
                    <span className="text-sm font-semibold text-zinc-100 truncate">{track.name}</span>
                  </div>
                  <button
                    type="button"
                    aria-label={`Toggle mute ${track.name}`}
                    onClick={() => updateTrackField(track.id, { muted: !track.muted })}
                    className="text-zinc-400 hover:text-zinc-100"
                  >
                    {track.muted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
                  </button>
                </div>

                <label className="block space-y-1">
                  <div className="flex justify-between text-xs text-zinc-400">
                    <span>Fader Level</span>
                    <span className="font-mono tabular-nums">{Math.round(track.volume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1.2}
                    step={0.01}
                    value={track.volume}
                    onChange={(e) => updateTrackField(track.id, { volume: Number(e.target.value) })}
                    className="w-full studio-slider accent-amber-500"
                  />
                </label>

                <label className="block space-y-1">
                  <div className="flex justify-between text-xs text-zinc-400">
                    <span>Stereo Pan</span>
                    <span className="font-mono tabular-nums">
                      {track.pan === 0 ? 'C' : track.pan < 0 ? `L${Math.round(Math.abs(track.pan) * 100)}` : `R${Math.round(track.pan * 100)}`}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-1}
                    max={1}
                    step={0.05}
                    value={track.pan}
                    onChange={(e) => updateTrackField(track.id, { pan: Number(e.target.value) })}
                    className="w-full studio-slider accent-amber-500"
                  />
                </label>

                <label className="block space-y-1">
                  <div className="flex justify-between text-xs text-zinc-400">
                    <span>Reverb Send</span>
                    <span className="font-mono tabular-nums">{Math.round(track.reverbSend * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={track.reverbSend}
                    onChange={(e) => updateTrackField(track.id, { reverbSend: Number(e.target.value) })}
                    className="w-full studio-slider accent-violet-400"
                  />
                </label>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <label className="block space-y-1">
                    <span className="text-[11px] text-zinc-400 block">Low EQ ({track.eqLow > 0 ? `+${track.eqLow}` : track.eqLow}dB)</span>
                    <input
                      type="range"
                      min={-12}
                      max={12}
                      step={0.5}
                      value={track.eqLow}
                      onChange={(e) => updateTrackField(track.id, { eqLow: Number(e.target.value) })}
                      className="w-full studio-slider accent-emerald-500"
                    />
                  </label>
                  <label className="block space-y-1">
                    <span className="text-[11px] text-zinc-400 block">High EQ ({track.eqHigh > 0 ? `+${track.eqHigh}` : track.eqHigh}dB)</span>
                    <input
                      type="range"
                      min={-12}
                      max={12}
                      step={0.5}
                      value={track.eqHigh}
                      onChange={(e) => updateTrackField(track.id, { eqHigh: Number(e.target.value) })}
                      className="w-full studio-slider accent-sky-400"
                    />
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {studioSubTab === 'songbook' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 studio-rack rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-semibold text-zinc-100">Interactive Chord Chart</h2>
                <p className="text-xs text-zinc-400">Current Key: <span className="text-amber-400 font-mono">{project.musicalKey}</span></p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => transposeProject(-1)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#191C24] hover:bg-zinc-800 border border-zinc-700 text-xs font-mono text-zinc-200"
                >
                  Transpose -1
                </button>
                <button
                  type="button"
                  onClick={() => transposeProject(1)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#191C24] hover:bg-zinc-800 border border-zinc-700 text-xs font-mono text-zinc-200"
                >
                  Transpose +1
                </button>
                <button
                  type="button"
                  onClick={addChordSection}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-100 flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Section
                </button>
              </div>
            </div>
            <div className="space-y-3">
              {project.chordChart.map((item) => (
                <div key={item.id} className="p-4 rounded-xl bg-[#191C24] border border-zinc-800 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        aria-label={`Section name ${item.section}`}
                        value={item.section}
                        onChange={(e) =>
                          onUpdateProject((prev) => ({
                            ...prev,
                            chordChart: prev.chordChart.map((c) => (c.id === item.id ? { ...c, section: e.target.value } : c)),
                          }))
                        }
                        className="bg-[#0D0F14] border border-zinc-700 rounded-md px-2.5 py-1 text-sm font-semibold text-amber-400 w-36"
                      />
                      <button
                        type="button"
                        onClick={() => playChordSection(item.chords)}
                        className="px-2.5 py-1 rounded-md bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-xs font-medium text-amber-300"
                      >
                        Play Progression
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {item.chords.map((ch, idx) => (
                        <button
                          key={`${item.id}-${idx}`}
                          type="button"
                          onClick={() => {
                            const parsed = parseChordSymbol(ch, 4);
                            audioEngine.triggerChord(parsed.midis, 0.85, 'electric-piano');
                          }}
                          className="px-3 py-1 rounded-md bg-[#0D0F14] border border-zinc-700 hover:border-amber-500 text-sm font-mono font-semibold text-zinc-100"
                        >
                          {ch}
                        </button>
                      ))}
                    </div>
                  </div>
                  <input
                    type="text"
                    aria-label={`Lyrics or arrangement cues for ${item.section}`}
                    value={item.lyrics}
                    onChange={(e) =>
                      onUpdateProject((prev) => ({
                        ...prev,
                        chordChart: prev.chordChart.map((c) => (c.id === item.id ? { ...c, lyrics: e.target.value } : c)),
                      }))
                    }
                    className="w-full bg-[#0D0F14] border border-zinc-800 rounded-md px-3 py-2 text-xs text-zinc-300"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center gap-2 text-zinc-100 font-semibold text-base">
              <Music className="w-4 h-4 text-amber-400" />
              <span>Songbook Entry</span>
            </div>
            <label className="block space-y-1">
              <span className="text-xs text-zinc-400">Artist / Ministry / Collective</span>
              <input
                type="text"
                value={project.songbook.artist}
                onChange={(e) =>
                  onUpdateProject((prev) => ({ ...prev, songbook: { ...prev.songbook, artist: e.target.value } }))
                }
                className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-100"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-zinc-400">Guitar Capo Fret</span>
              <input
                type="number"
                min={0}
                max={9}
                value={project.songbook.capo}
                onChange={(e) =>
                  onUpdateProject((prev) => ({ ...prev, songbook: { ...prev.songbook, capo: Number(e.target.value) || 0 } }))
                }
                className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-sm font-mono text-zinc-100"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-zinc-400">Arrangement & Performance Notes</span>
              <textarea
                rows={5}
                value={project.songbook.notes}
                onChange={(e) =>
                  onUpdateProject((prev) => ({ ...prev, songbook: { ...prev.songbook, notes: e.target.value } }))
                }
                className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-200"
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
};
