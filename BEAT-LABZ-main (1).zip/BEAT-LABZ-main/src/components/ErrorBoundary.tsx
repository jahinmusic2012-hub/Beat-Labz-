import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, message: error.message || 'An unexpected studio error occurred.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0A0B0E] text-zinc-100 flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-[#12141A] border border-red-500/30 rounded-xl p-6 space-y-4">
            <h2 className="text-lg font-semibold text-red-400">Studio Recovery Mode</h2>
            <p className="text-sm text-zinc-300 leading-relaxed break-words">{this.state.message}</p>
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, message: '' })}
              className="px-4 py-2 rounded-lg bg-amber-500 text-zinc-950 font-medium text-sm hover:bg-amber-400 transition-colors"
            >
              Restore Workspace
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
