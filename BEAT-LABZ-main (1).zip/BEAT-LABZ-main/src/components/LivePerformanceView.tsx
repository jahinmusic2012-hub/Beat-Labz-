import React, { useEffect, useState } from 'react';
import {
  VolumeX,
  Volume2,
  SkipBack,
  SkipForward,
  Play,
  Square,
  Plus,
  WifiOff,
  Usb,
  Trash2,
} from 'lucide-react';
import type { MidiFootMapping, SetlistItem, StudioProject } from '../types/studio';
import { INITIAL_MIDI_MAPPINGS, INITIAL_SETLIST } from '../data/defaultStudio';
import { audioEngine } from '../audio/audioEngine';
import { parseChordSymbol } from '../utils/musicTheory';

interface LivePerformanceViewProps {
  project: StudioProject;
  isPlaying: boolean;
  onTogglePlay: () => void;
  metronomeOn: boolean;
  onToggleMetronome: () => void;
  emergencyMuted: boolean;
  onToggleEmergencyMute: () => void;
  onUpdateBpm: (bpm: number) => void;
  onUpdateTrackVolume: (trackId: string, volume: number) => void;
}

const OFFLINE_CACHE_KEY = 'beatlabz_offline_setlist_v1';

export const LivePerformanceView: React.FC<LivePerformanceViewProps> = ({
  project,
  isPlaying,
  onTogglePlay,
  metronomeOn,
  onToggleMetronome,
  emergencyMuted,
  onToggleEmergencyMute,
  onUpdateBpm,
  onUpdateTrackVolume,
}) => {
  const [setlist, setSetlist] = useState<SetlistItem[]>(() => {
    try {
      const cached = localStorage.getItem(OFFLINE_CACHE_KEY);
      if (cached) return JSON.parse(cached) as SetlistItem[];
    } catch {
      // ignore
    }
    return INITIAL_SETLIST;
  });
  const [activeSongIdx, setActiveSongIdx] = useState(0);
  const [offlineMode, setOfflineMode] = useState(() => localStorage.getItem(OFFLINE_CACHE_KEY) !== null);
  const [midiMappings, setMidiMappings] = useState<MidiFootMapping[]>(INITIAL_MIDI_MAPPINGS);
  const [midiStatus, setMidiStatus] = useState<string>('Connect USB/Bluetooth MIDI pedal or use foot-trigger buttons below.');
  const [newSongTitle, setNewSongTitle] = useState('');
  const [newSongBpm, setNewSongBpm] = useState(110);
  const [newSongKey, setNewSongKey] = useState('G Major');
  const [newSongChords, setNewSongChords] = useState('G, D/F#, Em7, Cadd9');

  const activeSong = setlist[activeSongIdx] ?? setlist[0];

  useEffect(() => {
    if (offlineMode) {
      localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify(setlist));
    }
  }, [offlineMode, setlist]);

  const switchSong = (nextIdx: number) => {
    const clamped = (nextIdx + setlist.length) % setlist.length;
    setActiveSongIdx(clamped);
    const song = setlist[clamped];
    if (song) onUpdateBpm(song.bpm);
  };

  const executeMappedAction = (action: MidiFootMapping['action']) => {
    if (action === 'next_song') switchSong(activeSongIdx + 1);
    else if (action === 'prev_song') switchSong(activeSongIdx - 1);
    else if (action === 'toggle_play') onTogglePlay();
    else if (action === 'toggle_metronome') onToggleMetronome();
    else if (action === 'emergency_mute') onToggleEmergencyMute();
  };

  const connectWebMidi = async () => {
    const nav = navigator as Navigator & { requestMIDIAccess?: () => Promise<MIDIAccess> };
    if (!nav.requestMIDIAccess) {
      setMidiStatus('Web MIDI API is unavailable in this browser; hardware pedals can be tested via manual triggers.');
      return;
    }
    try {
      const access = await nav.requestMIDIAccess();
      let count = 0;
      access.inputs.forEach((input) => {
        count++;
        input.onmidimessage = (event) => {
          const [status, data1, data2] = event.data ?? [];
          if (!status) return;
          const isCC = (status & 0xf0) === 0xb0 && (data2 ?? 0) > 64;
          const channel = (status & 0x0f) + 1;
          if (isCC) {
            const matched = midiMappings.find((m) => m.midiChannel === channel && m.ccNumber === data1);
            if (matched) executeMappedAction(matched.action);
          }
        };
      });
      setMidiStatus(count > 0 ? `Connected to ${count} MIDI controller input(s).` : 'Web MIDI ready — no hardware pedal plugged in yet.');
    } catch (err) {
      setMidiStatus(err instanceof Error ? err.message : 'MIDI permission denied.');
    }
  };

  const addSetlistSong = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSongTitle.trim()) return;
    const item: SetlistItem = {
      id: `set_${Date.now()}`,
      title: newSongTitle.trim(),
      bpm: Math.max(40, Math.min(260, newSongBpm)),
      musicalKey: newSongKey.trim() || 'C Major',
      timeSignature: '4/4',
      chords: newSongChords
        .split(',')
        .map((c) => c.trim())
        .filter(Boolean),
      notes: 'Custom stage entry',
    };
    setSetlist((prev) => [...prev, item]);
    setNewSongTitle('');
  };

  const toggleOfflineMode = () => {
    if (offlineMode) {
      localStorage.removeItem(OFFLINE_CACHE_KEY);
      setOfflineMode(false);
    } else {
      localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify(setlist));
      setOfflineMode(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stage Top Banner & Emergency Mute */}
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Live Performance Stage</h1>
          <p className="text-sm text-zinc-400">
            Stage-ready chord display, setlist switching, Web MIDI foot-controller mapping, live mixer & offline cache
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={toggleOfflineMode}
            className={`px-3.5 py-2.5 rounded-lg text-xs font-semibold border flex items-center gap-2 whitespace-nowrap ${
              offlineMode
                ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300'
                : 'bg-[#191C24] border-zinc-700 text-zinc-300 hover:border-zinc-500'
            }`}
          >
            <WifiOff className="w-4 h-4" />
            {offlineMode ? 'Offline Stage Cache Active' : 'Enable Offline Stage Mode'}
          </button>

          <button
            type="button"
            onClick={onToggleEmergencyMute}
            className={`px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap ${
              emergencyMuted
                ? 'bg-red-600 text-white ring-2 ring-red-400'
                : 'bg-red-600/20 text-red-400 border border-red-500/40 hover:bg-red-600 hover:text-white'
            }`}
          >
            {emergencyMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            {emergencyMuted ? 'MASTER MUTED — TAP TO UNMUTE' : 'EMERGENCY MUTE'}
          </button>
        </div>
      </div>

      {/* Main Stage Display: Giant Song, BPM, Chords & Transport */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#12141A] border border-zinc-800 rounded-xl p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="text-xs font-medium text-amber-400">
                Song {activeSongIdx + 1} of {setlist.length} · Key of {activeSong?.musicalKey} · {activeSong?.timeSignature}
              </div>
              <h2 className="text-3xl font-bold text-zinc-100 mt-1">{activeSong?.title}</h2>
            </div>

            <div className="text-right">
              <div className="text-4xl font-mono font-bold text-amber-400 tabular-nums">{project.bpm}</div>
              <div className="text-xs text-zinc-400">BPM · {metronomeOn ? 'Click ON' : 'Click OFF'}</div>
            </div>
          </div>

          {/* Large Stage Chord Display */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {activeSong?.chords.map((chord, idx) => (
              <button
                key={`${activeSong.id}-${idx}`}
                type="button"
                onClick={() => {
                  const parsed = parseChordSymbol(chord, 4);
                  audioEngine.triggerChord(parsed.midis, 0.9, 'worship-pad');
                }}
                className="h-28 rounded-xl bg-[#191C24] hover:bg-amber-500/15 border border-zinc-700 hover:border-amber-500 flex flex-col items-center justify-center transition-colors"
              >
                <span className="text-3xl font-mono font-bold text-zinc-100">{chord}</span>
                <span className="text-xs text-zinc-400 mt-1">Bar {idx + 1} · Tap to Cue</span>
              </button>
            ))}
          </div>

          <p className="text-sm text-zinc-300 bg-[#0D0F14] border border-zinc-800 rounded-lg p-3">
            Stage Cue: {activeSong?.notes}
          </p>

          {/* Stage Transport Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => switchSong(activeSongIdx - 1)}
              className="px-4 py-3 rounded-xl bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-sm font-medium text-zinc-100 flex items-center gap-2"
            >
              <SkipBack className="w-4 h-4" /> Prev Song
            </button>
            <button
              type="button"
              onClick={onTogglePlay}
              className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-bold flex items-center gap-2"
            >
              {isPlaying ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
              {isPlaying ? 'Stop Backing' : 'Start Backing'}
            </button>
            <button
              type="button"
              onClick={onToggleMetronome}
              className={`px-4 py-3 rounded-xl border text-sm font-medium ${
                metronomeOn
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                  : 'bg-[#191C24] border-zinc-700 text-zinc-300'
              }`}
            >
              {metronomeOn ? 'Metronome ON' : 'Metronome OFF'}
            </button>
            <button
              type="button"
              onClick={() => switchSong(activeSongIdx + 1)}
              className="px-4 py-3 rounded-xl bg-[#191C24] hover:bg-zinc-700 border border-zinc-700 text-sm font-medium text-zinc-100 flex items-center gap-2"
            >
              Next Song <SkipForward className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Setlist Manager */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h3 className="text-base font-semibold text-zinc-100">Setlist Manager</h3>
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {setlist.map((song, idx) => (
              <div
                key={song.id}
                className={`p-3 rounded-lg border flex items-center justify-between gap-2 ${
                  idx === activeSongIdx
                    ? 'bg-amber-500/10 border-amber-500/50'
                    : 'bg-[#191C24] border-zinc-800'
                }`}
              >
                <button
                  type="button"
                  onClick={() => switchSong(idx)}
                  className="text-left flex-1 min-w-0"
                >
                  <div className="text-sm font-semibold text-zinc-100 truncate">
                    {idx + 1}. {song.title}
                  </div>
                  <div className="text-xs text-zinc-400 font-mono tabular-nums">
                    {song.bpm} BPM · {song.musicalKey}
                  </div>
                </button>
                {setlist.length > 1 && (
                  <button
                    type="button"
                    aria-label={`Remove ${song.title}`}
                    onClick={() => {
                      setSetlist((prev) => prev.filter((s) => s.id !== song.id));
                      if (activeSongIdx >= setlist.length - 1) setActiveSongIdx(0);
                    }}
                    className="p-1.5 text-zinc-500 hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <form onSubmit={addSetlistSong} className="space-y-2 pt-2 border-t border-zinc-800">
            <div className="text-xs font-medium text-zinc-300">Add Setlist Song</div>
            <input
              type="text"
              placeholder="Song Title"
              value={newSongTitle}
              onChange={(e) => setNewSongTitle(e.target.value)}
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                aria-label="Song BPM"
                value={newSongBpm}
                onChange={(e) => setNewSongBpm(Number(e.target.value))}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs font-mono text-zinc-100"
              />
              <input
                type="text"
                aria-label="Song Key"
                value={newSongKey}
                onChange={(e) => setNewSongKey(e.target.value)}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              />
            </div>
            <input
              type="text"
              aria-label="Comma separated chords"
              value={newSongChords}
              onChange={(e) => setNewSongChords(e.target.value)}
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs font-mono text-zinc-100"
            />
            <button
              type="submit"
              className="w-full py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-100 flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Add to Setlist
            </button>
          </form>
        </div>
      </div>

      {/* Live Stage Mixer + Foot-Controller MIDI Mapping */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h3 className="text-base font-semibold text-zinc-100">Live Stage Stem Mixer</h3>
          <div className="space-y-3">
            {project.tracks.map((track) => (
              <div key={track.id} className="flex items-center gap-4">
                <span className="w-32 text-xs font-medium text-zinc-200 truncate">{track.name}</span>
                <input
                  type="range"
                  aria-label={`Stage volume ${track.name}`}
                  min={0}
                  max={1.2}
                  step={0.01}
                  value={track.volume}
                  onChange={(e) => onUpdateTrackVolume(track.id, Number(e.target.value))}
                  className="flex-1 accent-amber-500"
                />
                <span className="w-12 text-right text-xs font-mono text-zinc-400 tabular-nums">
                  {Math.round(track.volume * 100)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-base font-semibold text-zinc-100">Foot-Controller MIDI Mapping</h3>
            <button
              type="button"
              onClick={connectWebMidi}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-amber-400 flex items-center gap-1.5"
            >
              <Usb className="w-3.5 h-3.5" /> Connect MIDI Pedal
            </button>
          </div>
          <p className="text-xs text-zinc-400">{midiStatus}</p>

          <div className="space-y-2">
            {midiMappings.map((m) => (
              <div key={m.id} className="flex items-center justify-between gap-2 bg-[#191C24] border border-zinc-800 rounded-lg px-3 py-2">
                <span className="text-xs font-medium text-zinc-200 flex-1">{m.label}</span>
                <label className="flex items-center gap-1 text-[11px] text-zinc-400">
                  CC#
                  <input
                    type="number"
                    min={0}
                    max={127}
                    value={m.ccNumber}
                    onChange={(e) =>
                      setMidiMappings((prev) =>
                        prev.map((item) => (item.id === m.id ? { ...item, ccNumber: Number(e.target.value) } : item))
                      )
                    }
                    className="w-14 bg-[#0D0F14] border border-zinc-700 rounded px-1.5 py-1 text-xs font-mono text-zinc-100"
                  />
                </label>
                <button
                  type="button"
                  onClick={() => executeMappedAction(m.action)}
                  className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-[11px] font-medium text-zinc-200"
                >
                  Trigger
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
